<!-- 封面 -->

<!-- ![logo](../public/images/image_icon_153794.png) -->
# EasyImage <small>2.0</small>

> 简单图床 - 无数据库的图床程序

- 始于2018年7月，支持多文件上传，功能强大
- 本程序对于环境要求极低

[GitHub](https://github.com/icret/EasyImages2.0)
[DEMO](https://png.cm/)

<!-- ![color](#f1939c) -->