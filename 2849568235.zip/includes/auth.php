<?php
return [
    'app_version' => '1.3',
];
?>