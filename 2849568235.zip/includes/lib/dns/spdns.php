<?php

namespace lib\dns;

use lib\DnsInterface;

class spdns implements DnsInterface
{
    private $apiid;
    private $apisecret;
    private $baseUrl;
    private $userId;
    private $apiKey;
    private $error;
    private $domain;
    private $domainid;
    private $proxy;

    public function __construct($config)
    {
        $this->apiid = $config['ak'] ?? '';          // API URL
        $this->apisecret = $config['sk'] ?? '';      // API Token (如果使用签名则为用户ID)
        $this->domain = $config['domain'] ?? '';
        $this->domainid = $config['domainid'] ?? '';
        $this->proxy = isset($config['proxy']) ? $config['proxy'] == 1 : false;
        $this->baseUrl = rtrim($this->apiid, '/');
        
        // 对于SPDNS，可能需要额外解析配置
        // 假设配置格式: ak=API地址, sk=用户ID:API密钥
        $skParts = explode(':', $this->apisecret);
        if (count($skParts) >= 2) {
            $this->userId = $skParts[0];
            $this->apiKey = $skParts[1];
        }
    }

    public function getError()
    {
        return $this->error;
    }

    private function setError($message)
    {
        $this->error = $message;
    }

    public function check()
    {
        // 尝试获取域名列表来测试连接
        $result = $this->getDomainList();
        return $result !== false;
    }

    // 获取域名列表
    public function getDomainList($KeyWord = null, $PageNumber = 1, $PageSize = 20)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        $timestamp = time();
        $signature = $this->generateSignature($timestamp);
        
        $params = [
            'user_id' => $this->userId,
            'apikey' => $this->apiKey,
            'timestamp' => $timestamp,
            'signature' => $signature
        ];
        
        $url = $this->baseUrl . '/api/v1/domains?' . http_build_query($params);
        
        $response = $this->execute('GET', $url);
        
        if (!$response) {
            return false;
        }
        
        // 检查API响应格式
        if (isset($response['success'])) {
            if (!$response['success']) {
                $this->setError('API错误: ' . ($response['message'] ?? '未知错误'));
                return false;
            }
            $data = $response['data'] ?? [];
        } elseif (isset($response['code'])) {
            if ($response['code'] !== 200) {
                $this->setError('API错误: ' . ($response['message'] ?? '未知错误'));
                return false;
            }
            $data = $response['data'] ?? [];
        } else {
            $this->setError('API响应格式不正确');
            return false;
        }
        
        $list = [];
        if (is_array($data)) {
            foreach ($data as $domain) {
                $domainData = [
                    'DomainId' => $domain['id'] ?? $domain['domain'] ?? '',
                    'Domain' => $domain['domain'] ?? '',
                    'RecordCount' => 0,
                ];
                
                // 如果域名来自商城（包含shop_前缀或is_shop标识），添加相应标识
                if (isset($domain['is_shop']) && $domain['is_shop']) {
                    $domainData['is_shop'] = true;
                    $domainData['shop_id'] = $domain['shop_id'] ?? null;
                    $domainData['is_buyout'] = $domain['is_buyout'] ?? false;
                    $domainData['description'] = $domain['description'] ?? '';
                    
                    // 如果domainId不是以shop_开头，添加前缀
                    if (!str_starts_with($domainData['DomainId'], 'shop_')) {
                        $domainData['DomainId'] = 'shop_' . $domainData['DomainId'];
                    }
                }
                
                $list[] = $domainData;
            }
        }
        
        return ['total' => count($list), 'list' => $list];
    }

    // 获取解析记录列表
    public function getDomainRecords($PageNumber = 1, $PageSize = 20, $KeyWord = null, $SubDomain = null, $Value = null, $Type = null, $Line = null, $Status = null)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        $timestamp = time();
        $signature = $this->generateSignature($timestamp);
        
        $params = [
            'user_id' => $this->userId,
            'apikey' => $this->apiKey,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'domain' => $this->domain
        ];
        
        // 如果是商城域名，添加相应参数
        if ($this->domainid && str_starts_with($this->domainid, 'shop_')) {
            $params['shop_domain'] = true;
            $params['shop_id'] = str_replace('shop_', '', $this->domainid);
        }
        
        if ($SubDomain) {
            $params['host'] = $SubDomain;
        }
        
        $url = $this->baseUrl . '/api/v1/records?' . http_build_query($params);
        
        $response = $this->execute('GET', $url);
        
        if (!$response) {
            return false;
        }
        
        if (isset($response['code']) && $response['code'] !== 200) {
            $this->setError('API错误: ' . (($response && isset($response['message'])) ? $response['message'] : '未知错误'));
            return false;
        }
        
        $list = [];
        if (isset($response['data']) && is_array($response['data'])) {
            foreach ($response['data'] as $record) {
                $list[] = [
                    'RecordId' => $record['id'] ?? '',
                    'Domain' => $this->domain,
                    'Name' => $record['name'] ?? '',
                    'Type' => strtoupper($record['type'] ?? 'A'),
                    'Value' => $record['value'] ?? '',
                    'Line' => $record['line'] ?? '默认',
                    'TTL' => $record['ttl'] ?? 600,
                    'MX' => isset($record['priority']) ? $record['priority'] : ($record['preference'] ?? null),
                    'Status' => ($record['status'] ?? 1) ? '1' : '0',
                    'Weight' => $record['weight'] ?? null,
                    'Remark' => $record['remark'] ?? null,
                    'UpdateTime' => isset($record['updated_at']) ? date('Y-m-d H:i:s', $record['updated_at']) : ''
                ];
            }
        }
        
        return ['total' => count($list), 'list' => $list];
    }

    // 获取子域名解析记录列表
    public function getSubDomainRecords($SubDomain, $PageNumber = 1, $PageSize = 20, $Type = null, $Line = null)
    {
        if ($SubDomain == '') {
            $SubDomain = '@';
        }
        return $this->getDomainRecords($PageNumber, $PageSize, null, $SubDomain, null, $Type, $Line);
    }

    // 获取解析记录详细信息
    public function getDomainRecordInfo($RecordId)
    {
        // SPDNS API 可能没有单独获取记录详情的接口
        return false;
    }

    // 添加解析记录
    public function addDomainRecord($Name, $Type, $Value, $Line = 'tele', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        if (!$this->validateRecordData($Type, $Value)) {
            return false;
        }

        $timestamp = time();
        $signature = $this->generateSignature($timestamp);
        
        $data = [
            'user_id' => $this->userId,
            'apikey' => $this->apiKey,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'domain' => $this->domain,
            'name' => $Name ?: '@',
            'type' => strtoupper($Type),
            'value' => $Value,
            'ttl' => intval($TTL)
        ];
        
        
        // 从用户域名信息中获取天数参数
        $userDomainDays = $this->getUserDomainDays($this->domain, $Name, $Type, $Value);
        if ($userDomainDays > 0) {
            $data['days'] = $userDomainDays;
        }

       
        
        // 添加可选参数
        if (in_array(strtoupper($Type), ['MX'])) {
            $data['priority'] = intval($MX);
        }
        if ($Line && $Line != 'tele') {
            $data['line'] = $Line;
        }
        
        // 如果是商城域名，添加相应参数
        if ($this->domainid && str_starts_with($this->domainid, 'shop_')) {
            $data['shop_domain'] = true;
            $data['shop_id'] = str_replace('shop_', '', $this->domainid);
        }
        
        $url = $this->baseUrl . '/api/v1/records';
        
        $response = $this->execute('POST', $url, $data);
        if (!$response) {
            return false;
        }
        
        // 兼容新旧API响应格式
        $isSuccess = false;
        $recordId = null;
        $errorMessage = '未知错误';
        
        if (isset($response['success'])) {
            // 新格式：{"success": true, "data": {"record_id": "..."}}
            $isSuccess = $response['success'];
            if ($isSuccess && isset($response['data']['record_id'])) {
                $recordId = $response['data']['record_id'];
            }
            if (isset($response['message'])) {
                $errorMessage = $response['message'];
            }
        } elseif (isset($response['code'])) {
            // 旧格式：{"code": 200, "data": {"record_id": "..."}}
            $isSuccess = ($response['code'] === 200);
            if ($isSuccess && isset($response['data']['record_id'])) {
                $recordId = $response['data']['record_id'];
            }
            if (isset($response['message'])) {
                $errorMessage = $response['message'];
            }
        }
        
        if (!$isSuccess) {
            // 检查是否是数据库相关错误
            if (strpos($errorMessage, 'SQLSTATE') !== false || strpos($errorMessage, 'datetime') !== false) {
                $errorMessage = '保存记录失败: 数据库执行失败: ' . $errorMessage;
            } else {
                $errorMessage = '添加记录失败: ' . $errorMessage;
            }
            $this->setError($errorMessage);
            return false;
        }
        
        return $recordId;
    }

    // 修改解析记录
    public function updateDomainRecord($RecordId, $Name, $Type, $Value, $Line = '0', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        if (!$this->validateRecordData($Type, $Value)) {
            return false;
        }

        $timestamp = time();
        $signature = $this->generateSignature($timestamp);
        
        $data = [
            'user_id' => $this->userId,
            'apikey' => $this->apiKey,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'record_id' => $RecordId
        ];
        
        // 添加需要更新的字段
        if (isset($Name)) {
            $data['name'] = $Name;
        }
        if (isset($Type)) {
            $data['type'] = strtoupper($Type);
        }
        if (isset($Value)) {
            $data['value'] = $Value;
        }
        if (isset($TTL)) {
            $data['ttl'] = intval($TTL);
        }
        if (isset($MX) && in_array(strtoupper($Type), ['MX'])) {
            $data['priority'] = intval($MX);
        }
        if (isset($Line) && $Line != '0') {
            $data['line'] = $Line;
        }
        
        // 如果是商城域名，添加相应参数
        if ($this->domainid && str_starts_with($this->domainid, 'shop_')) {
            $data['shop_domain'] = true;
            $data['shop_id'] = str_replace('shop_', '', $this->domainid);
        }
        
        $url = $this->baseUrl . '/api/v1/records/edit';
        
        $response = $this->execute('POST', $url, $data);
        
        if (!$response) {
            return false;
        }
        
        // 兼容新旧API响应格式
        $isSuccess = false;
        
        if (isset($response['success'])) {
            $isSuccess = $response['success'];
        } elseif (isset($response['code'])) {
            $isSuccess = ($response['code'] === 200);
        }
        
        if (!$isSuccess) {
            $errorMessage = $response['message'] ?? '编辑记录失败';
            $this->setError($errorMessage);
            return false;
        }
        
        return true;
    }

    // 修改解析记录备注
    public function updateDomainRecordRemark($RecordId, $Remark)
    {
        // SPDNS API 可能不支持修改备注
        return false;
    }

    // 删除解析记录
    public function deleteDomainRecord($RecordId)
    {
        if (!$this->validateCredentials()) {
            return false;
        }

        $timestamp = time();
        $signature = $this->generateSignature($timestamp);
        
        $data = [
            'user_id' => $this->userId,
            'apikey' => $this->apiKey,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'record_id' => $RecordId
        ];
        
        // 如果是商城域名，添加相应参数
        if ($this->domainid && str_starts_with($this->domainid, 'shop_')) {
            $data['shop_domain'] = true;
            $data['shop_id'] = str_replace('shop_', '', $this->domainid);
        }
        
        $url = $this->baseUrl . '/api/v1/records/delete';
        
        $response = $this->execute('POST', $url, $data);
        
        if (!$response) {
            return false;
        }
        
        // 兼容新旧API响应格式
        $isSuccess = false;
        
        if (isset($response['success'])) {
            $isSuccess = $response['success'];
        } elseif (isset($response['code'])) {
            $isSuccess = ($response['code'] === 200);
        }
        
        if (!$isSuccess) {
            $errorMessage = $response['message'] ?? '删除记录失败';
            $this->setError($errorMessage);
            return false;
        }
        
        return true;
    }

    // 设置解析记录状态
    public function setDomainRecordStatus($RecordId, $Status)
    {
        if (!$this->validateCredentials()) {
            return false;
        }

        $timestamp = time();
        $signature = $this->generateSignature($timestamp);
        
        $data = [
            'user_id' => $this->userId,
            'apikey' => $this->apiKey,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'record_id' => $RecordId,
            'status' => $Status == '1' ? 1 : 0
        ];
        
        // 如果是商城域名，添加相应参数
        if ($this->domainid && str_starts_with($this->domainid, 'shop_')) {
            $data['shop_domain'] = true;
            $data['shop_id'] = str_replace('shop_', '', $this->domainid);
        }
        
        $url = $this->baseUrl . '/api/v1/records/status';
        
        $response = $this->execute('POST', $url, $data);
        
        if (!$response) {
            return false;
        }
        
        // 兼容新旧API响应格式
        $isSuccess = false;
        
        if (isset($response['success'])) {
            $isSuccess = $response['success'];
        } elseif (isset($response['code'])) {
            $isSuccess = ($response['code'] === 200);
        }
        
        if (!$isSuccess) {
            $errorMessage = $response['message'] ?? '设置记录状态失败';
            $this->setError($errorMessage);
            return false;
        }
        
        return true;
    }

    // 获取解析记录操作日志
    public function getDomainRecordLog($PageNumber = 1, $PageSize = 20, $KeyWord = null, $StartDate = null, $endDate = null)
    {
        // SPDNS API 可能不支持获取操作日志
        return false;
    }

    // 获取解析线路列表
    public function getRecordLine()
    {
        // SPDNS API 可能不支持线路选择，返回默认线路
        return ['默认' => ['name' => '默认线路', 'parent' => null]];
    }

    // 获取域名信息
    public function getDomainInfo()
    {
        // SPDNS API 可能没有直接获取域名信息的接口
        return false;
    }

    // 获取域名最低TTL
    public function getMinTTL()
    {
        // SPDNS API 可能不支持获取最低TTL
        return 600; // 返回默认值
    }

    // 添加域名（可能需要特定的API）
    public function addDomain($Domain)
    {
        $this->setError('SPDNS 不支持通过API添加域名');
        return false;
    }

    // 续费DNS记录
    public function renewRecord($domain, $recordId, $renewData = [])
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        // 从续费数据中提取参数
        $months = $renewData['months'] ?? 1;
        $packageInfo = $renewData['package_info'] ?? [];
        
        // 生成签名
        $timestamp = time();
        $signature = $this->generateSignature($timestamp);
        
        // 构建续费请求参数（与对接站 ApiController 保持一致）
        $data = [
            'user_id' => $this->userId,
            'apikey' => $this->apiKey,
            'timestamp' => $timestamp,
            'signature' => $signature,
            'record_id' => $recordId,
            // 兼容旧调用：传 months 给对接站备用（其会忽略）
            'months' => $months,
            // 对接站参数：续费数量，默认 1
            'renew_quantity' => 1
        ];

        // 如果有套餐信息，传递套餐名称；避免误用 sort_order 作为索引
        if (!empty($packageInfo)) {
            if (isset($packageInfo['sort_order'])) {
                $data['package_index'] = intval($packageInfo['sort_order']);
            }
            // 支持自定义价格与天数（由前端或调用方计算）
            if (isset($renewData['total_cost'])) {
                $data['custom_price'] = $renewData['total_cost'];
            }
            if (isset($packageInfo['days'])) {
                $data['custom_days'] = $packageInfo['days'];
            }
        }
        
        $url = $this->baseUrl . '/api/v1/records/renew';
        
        $response = $this->execute('POST', $url, $data);
        
        if (!$response) {
            $this->setError('API续费请求失败');
            return false;
        }
        
        // 检查API响应
        if (isset($response['code']) && $response['code'] !== 200) {
            $errorMsg = 'API续费失败';
            if ($response && isset($response['message'])) {
                $errorMsg .= ': ' . $response['message'];
            }
            
            $this->setError($errorMsg);
            return false;
        }
        
        return true;
    }

    // 私有方法

    private function validateCredentials()
    {
        if (empty($this->apiid) || empty($this->apisecret)) {
            $this->setError('API凭证配置不完整');
            return false;
        }
        
        if (!$this->userId || !$this->apiKey) {
            $this->setError('API密钥格式错误，应为 user_id:api_key 格式');
            return false;
        }
        
        return true;
    }

    private function validateRecordData($type, $value)
    {
        $validTypes = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA'];
        
        if (!in_array(strtoupper($type), $validTypes)) {
            $this->setError('不支持的记录类型: ' . $type);
            return false;
        }
        
        if (empty($value)) {
            $this->setError('记录值不能为空');
            return false;
        }
        
        return true;
    }

    private function generateSignature($timestamp)
    {
        // 根据API文档，签名算法为: hash('sha256', $user_id . $apikey . $timestamp)
        return hash('sha256', $this->userId . $this->apiKey . $timestamp);
    }

    private function getUserDomainDays($domain, $name, $type, $value)
    {
        // 简化实现，返回0表示不需要天数参数
        // 实际应用中可能需要查询数据库或其他逻辑
        return 0;
    }

    private function execute($method, $url, $data = null)
    {
        $ch = curl_init($url);
        
        $headers = ['Content-Type: application/json; charset=utf-8'];
        
        if ($this->proxy) {
            // 如果需要代理设置
            curl_setopt($ch, CURLOPT_PROXY, $this->proxy);
        }
        
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        
        if ($method == 'POST' && $data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($errno) {
            $this->setError('Curl错误: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
        
        if ($httpCode !== 200) {
            $this->setError('HTTP错误: ' . $httpCode);
            return false;
        }
        
        $decodedResponse = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->setError('JSON解析错误: ' . json_last_error_msg());
            return false;
        }
        
        return $decodedResponse;
    }
}