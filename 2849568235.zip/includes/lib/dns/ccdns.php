<?php

namespace lib\dns;

use lib\DnsInterface;

class ccdns implements DnsInterface
{
    private $apiid;
    private $apisecret;
    private $baseUrl;
    private $error;
    private $domain;
    private $domainid;
    private $proxy;
    private $uid;
    private $key;

    public function __construct($config)
    {
        $this->apiid = $config['ak'] ?? '';          // API URL
        $this->apisecret = $config['sk'] ?? '';      // API密钥
        $this->domain = $config['domain'] ?? '';
        $this->domainid = $config['domainid'] ?? '';
        $this->proxy = isset($config['proxy']) ? $config['proxy'] == 1 : false;
        $this->baseUrl = rtrim($this->apiid, '/');
        
        // 解析API密钥配置（格式：uid:key）
        $skParts = explode(':', $this->apisecret);
        if (count($skParts) >= 2) {
            $this->uid = $skParts[0];
            $this->key = $skParts[1];
        } else {
            // 如果没有冒号分隔，假设sk就是key，需要uid单独提供
            $this->key = $this->apisecret;
            $this->uid = $config['uid'] ?? '';
        }
    }

    public function getError()
    {
        return $this->error;
    }

    private function setError($message)
    {
        $this->error = $message;
    }

    public function check()
    {
        // 通过获取域名列表测试连接
        $result = $this->getDomainList();
        return $result !== false;
    }

    // 获取域名列表
    public function getDomainList($KeyWord = null, $PageNumber = 1, $PageSize = 20)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        $timestamp = time();
        $sign = $this->generateSign($timestamp);
        
        $params = [
            'uid' => $this->uid,
            'timestamp' => $timestamp,
            'sign' => $sign,
            'offset' => ($PageNumber - 1) * $PageSize,
            'limit' => $PageSize
        ];
        
        if ($KeyWord) {
            $params['kw'] = $KeyWord;
        }
        
        $url = $this->baseUrl . '/api/domain';
        
        $response = $this->execute('POST', $url, $params);
        
        if (!$response) {
            return false;
        }
        
        // 检查响应格式
        if (isset($response['code']) && $response['code'] !== 0) {
            $this->setError('API错误: ' . ($response['msg'] ?? '未知错误'));
            return false;
        }
        
        $list = [];
        if (isset($response['rows']) && is_array($response['rows'])) {
            foreach ($response['rows'] as $row) {
                $list[] = [
                    'DomainId' => $row['id'] ?? '',
                    'Domain' => $row['name'] ?? '',
                    'RecordCount' => $row['recordcount'] ?? 0,
                    'Platform' => $row['type'] ?? '',
                    'PlatformName' => $row['typename'] ?? '',
                    'AddTime' => $row['addtime'] ?? '',
                    'ExpireTime' => $row['expiretime'] ?? '',
                    'IsHide' => $row['is_hide'] ?? 0,
                    'IsSso' => $row['is_sso'] ?? 0,
                    'Remark' => $row['remark'] ?? ''
                ];
            }
        }
        
        return [
            'total' => $response['total'] ?? count($list),
            'list' => $list
        ];
    }

    // 获取解析记录列表
    public function getDomainRecords($PageNumber = 1, $PageSize = 20, $KeyWord = null, $SubDomain = null, $Value = null, $Type = null, $Line = null, $Status = null)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        $timestamp = time();
        $sign = $this->generateSign($timestamp);
        
        $params = [
            'uid' => $this->uid,
            'timestamp' => $timestamp,
            'sign' => $sign,
            'offset' => ($PageNumber - 1) * $PageSize,
            'limit' => $PageSize
        ];
        
        // 可选过滤参数
        if ($KeyWord) {
            $params['keyword'] = $KeyWord;
        }
        
        if ($SubDomain) {
            $params['subdomain'] = $SubDomain;
        }
        
        if ($Value) {
            $params['value'] = $Value;
        }
        
        if ($Type) {
            $params['type'] = $Type;
        }
        
        if ($Line) {
            $params['line'] = $Line;
        }
        
        if ($Status !== null) {
            $params['status'] = $Status;
        }
        
        $url = $this->baseUrl . '/api/record/data/' . $this->domainid;
        
        $response = $this->execute('POST', $url, $params);
        
        if (!$response) {
            return false;
        }
        
        // 检查响应格式
        if (isset($response['code']) && $response['code'] !== 0) {
            $this->setError('API错误: ' . ($response['msg'] ?? '未知错误'));
            return false;
        }
        
        $list = [];
        if (isset($response['rows']) && is_array($response['rows'])) {
            foreach ($response['rows'] as $row) {
                $list[] = [
                    'RecordId' => $row['RecordId'] ?? '',
                    'Domain' => $row['Domain'] ?? $this->domain,
                    'Name' => $row['Name'] ?? '',
                    'Type' => $row['Type'] ?? '',
                    'Value' => $row['Value'] ?? '',
                    'Line' => $row['Line'] ?? 'default',
                    'LineName' => $row['LineName'] ?? '默认',
                    'TTL' => $row['TTL'] ?? 600,
                    'MX' => $row['MX'] ?? null,
                    'Status' => $row['Status'] ?? '1',
                    'Weight' => $row['Weight'] ?? null,
                    'Remark' => $row['Remark'] ?? null,
                    'UpdateTime' => $row['UpdateTime'] ?? ''
                ];
            }
        }
        
        return [
            'total' => $response['total'] ?? count($list),
            'list' => $list
        ];
    }

    // 获取子域名解析记录列表
    public function getSubDomainRecords($SubDomain, $PageNumber = 1, $PageSize = 20, $Type = null, $Line = null)
    {
        if ($SubDomain == '') {
            $SubDomain = '@';
        }
        return $this->getDomainRecords($PageNumber, $PageSize, null, $SubDomain, null, $Type, $Line);
    }

    // 获取解析记录详细信息
    public function getDomainRecordInfo($RecordId)
    {
        // 通过获取记录列表并筛选特定RecordId来获取详细信息
        if (!$this->validateCredentials()) {
            return false;
        }
        
        $records = $this->getDomainRecords(1, 100);
        if (!$records) {
            return false;
        }
        
        foreach ($records['list'] as $record) {
            if ($record['RecordId'] == $RecordId) {
                return $record;
            }
        }
        
        $this->setError('未找到指定的解析记录');
        return false;
    }

    // 添加解析记录
    public function addDomainRecord($Name, $Type, $Value, $Line = 'tele', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {

       

        if (!$this->validateCredentials()) {
            return false;
        }
        
        if (!$this->validateRecordData($Type, $Value)) {
            return false;
        }
        
        $timestamp = time();
        $sign = $this->generateSign($timestamp);
        
        $params = [
            'uid' => $this->uid,
            'timestamp' => $timestamp,
            'sign' => $sign,
            'name' => $Name,
            'type' => strtoupper($Type),
            'value' => $Value,
            'line' => $this->convertLine($Line),
            'ttl' => intval($TTL)
        ];

        
        
        // 可选参数
        if (in_array(strtoupper($Type), ['MX']) && $MX) {
            $params['mx'] = intval($MX);
        }
        
        if ($Weight !== null) {
            $params['weight'] = intval($Weight);
        }
        
        if ($Remark !== null) {
            $params['remark'] = $Remark;
        }
        
        $url = $this->baseUrl . '/api/record/add/' . $this->domainid;
        
        $response = $this->execute('POST', $url, $params);
        
        if (!$response) {
            return false;
        }
        
        if (isset($response['code']) && $response['code'] === 0) {
            // 添加成功，尝试获取记录ID
            $recordId = $this->getRecordIdAfterAdd($Name, $Type, $Value, $Line);
            if ($recordId) {
                return $recordId; // 返回记录ID
            } else {
                // 如果获取记录ID失败，返回true表示添加成功
                return true;
            }
        } else {
            $this->setError('添加记录失败: ' . ($response['msg'] ?? '未知错误'));
            return false;
        }
    }

    // 修改解析记录
    public function updateDomainRecord($RecordId, $Name, $Type, $Value, $Line = '0', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        if (!$this->validateRecordData($Type, $Value)) {
            return false;
        }
        
        $timestamp = time();
        $sign = $this->generateSign($timestamp);
        
        $params = [
            'uid' => $this->uid,
            'timestamp' => $timestamp,
            'sign' => $sign,
            'recordid' => $RecordId,
            'name' => $Name,
            'type' => strtoupper($Type),
            'value' => $Value,
            'line' => $this->convertLine($Line),
            'ttl' => intval($TTL)
        ];
    
        // 可选参数
        if (in_array(strtoupper($Type), ['MX']) && $MX) {
            $params['mx'] = intval($MX);
        }
        
        if ($Weight !== null) {
            $params['weight'] = intval($Weight);
        }
        
        if ($Remark !== null) {
            $params['remark'] = $Remark;
        }
        
        $url = $this->baseUrl . '/api/record/update/' . $this->domainid;
        
        $response = $this->execute('POST', $url, $params);
        if (!$response) {
            return false;
        }
        
        if (isset($response['code']) && $response['code'] === 0) {
            return true;
        } else {
            $this->setError('修改记录失败: ' . ($response['msg'] ?? '未知错误'));
            return false;
        }
    }

    // 修改解析记录备注
    public function updateDomainRecordRemark($RecordId, $Remark)
    {
        // 先获取记录当前信息
        $recordInfo = $this->getDomainRecordInfo($RecordId);
        if (!$recordInfo) {
            return false;
        }
        
        // 使用更新接口修改备注
        return $this->updateDomainRecord(
            $RecordId,
            $recordInfo['Name'],
            $recordInfo['Type'],
            $recordInfo['Value'],
            $recordInfo['Line'],
            $recordInfo['TTL'],
            $recordInfo['MX'] ?? 1,
            $recordInfo['Weight'],
            $Remark
        );
    }

    // 删除解析记录
    public function deleteDomainRecord($RecordId)
    {
        if (!$this->validateCredentials()) {
            return false;
        }
        
        $timestamp = time();
        $sign = $this->generateSign($timestamp);
        
        $params = [
            'uid' => $this->uid,
            'timestamp' => $timestamp,
            'sign' => $sign,
            'recordid' => $RecordId
        ];
        
        $url = $this->baseUrl . '/api/record/delete/' . $this->domainid;
        
        $response = $this->execute('POST', $url, $params);
        
        if (!$response) {
            return false;
        }
        
        if (isset($response['code']) && $response['code'] === 0) {
            return true;
        } else {
            $this->setError('删除记录失败: ' . ($response['msg'] ?? '未知错误'));
            return false;
        }
    }

    // 设置解析记录状态
    public function setDomainRecordStatus($RecordId, $Status)
    {
        // 聚合DNS文档未提供设置记录状态的接口
        // 先获取记录当前信息，然后通过更新接口来设置状态
        $recordInfo = $this->getDomainRecordInfo($RecordId);
        if (!$recordInfo) {
            return false;
        }
        
        // 注意：聚合DNS可能不支持通过更新接口设置状态
        // 我们尝试更新，但状态字段可能不会被API接受
        return $this->updateDomainRecord(
            $RecordId,
            $recordInfo['Name'],
            $recordInfo['Type'],
            $recordInfo['Value'],
            $recordInfo['Line'],
            $recordInfo['TTL'],
            $recordInfo['MX'] ?? 1,
            $recordInfo['Weight'],
            $recordInfo['Remark'] ?? ''
        );
    }

    // 获取解析记录操作日志
    public function getDomainRecordLog($PageNumber = 1, $PageSize = 20, $KeyWord = null, $StartDate = null, $endDate = null)
    {
        // 聚合DNS文档未提供获取操作日志的接口
        $this->setError('聚合DNS API 不支持获取操作日志功能');
        return false;
    }

    // 获取解析线路列表
    public function getRecordLine()
    {
        // 聚合DNS文档未提供获取线路列表的接口
        // 返回常见线路
        return [
            'default' => ['name' => '默认', 'parent' => null],
            '0' => ['name' => '默认', 'parent' => null],
            '1' => ['name' => '电信', 'parent' => null],
            '2' => ['name' => '联通', 'parent' => null],
            '3' => ['name' => '移动', 'parent' => null],
            '4' => ['name' => '教育网', 'parent' => null],
            '5' => ['name' => '铁通', 'parent' => null]
        ];
    }

    // 获取域名信息
    public function getDomainInfo()
    {
        // 通过域名列表接口获取当前域名信息
        $domains = $this->getDomainList();
        if (!$domains) {
            return false;
        }
        
        foreach ($domains['list'] as $domain) {
            if ($domain['DomainId'] == $this->domainid || $domain['Domain'] == $this->domain) {
                return $domain;
            }
        }
        
        $this->setError('未找到域名信息');
        return false;
    }

    // 获取域名最低TTL
    public function getMinTTL()
    {
        // 聚合DNS文档未提供获取最低TTL的接口
        return 600; // 返回默认值
    }

    // 添加域名
    public function addDomain($Domain)
    {
        // 聚合DNS文档未提供添加域名的接口
        $this->setError('聚合DNS API 不支持添加域名功能');
        return false;
    }

    // 私有方法

    private function validateCredentials()
    {
        if (empty($this->apiid) || empty($this->apisecret)) {
            $this->setError('API凭证配置不完整');
            return false;
        }
        
        if (empty($this->uid) || empty($this->key)) {
            $this->setError('用户ID或API密钥配置不完整');
            return false;
        }
        
        return true;
    }

    private function validateRecordData($type, $value)
    {
        $validTypes = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA'];
        
        if (!in_array(strtoupper($type), $validTypes)) {
            $this->setError('不支持的记录类型: ' . $type);
            return false;
        }
        
        if (empty($value)) {
            $this->setError('记录值不能为空');
            return false;
        }
        
        return true;
    }

    private function generateSign($timestamp)
    {
        // 签名规则：md5(uid + timestamp + key)
        $signStr = $this->uid . $timestamp . $this->key;
        return md5($signStr);
    }

    private function convertLine($line)
    {
        // 转换线路ID
        $lineMap = [
            'tele' => 'default',
            '默认' => 'default',
            'default' => 'default',
            '0' => 'default',
            '电信' => '1',
            '联通' => '2',
            '移动' => '3',
            '教育网' => '4',
            '铁通' => '5'
        ];
        
        return $lineMap[$line] ?? 'default';
    }

    // 添加记录后获取记录ID
    private function getRecordIdAfterAdd($name, $type, $value, $line)
    {
        // 等待一下，让API有时间处理新增记录
        sleep(2);
        
        // 尝试获取记录列表，查找匹配的记录
        $records = $this->getDomainRecords(1, 100, null, $name, null, $type, $line);
        
        if (!$records || empty($records['list'])) {
            // 如果没有找到记录，可能是因为API延迟，再试一次
            sleep(1);
            $records = $this->getDomainRecords(1, 100, null, $name, null, $type, $line);
        }
        
        if (!$records || empty($records['list'])) {
            // 仍然没有找到，记录错误但继续
            $this->setError('添加记录成功，但无法获取记录ID。您可以稍后通过查询获取。');
            return false;
        }
        
        // 遍历记录，找到值匹配的记录
        foreach ($records['list'] as $record) {
            if ($record['Value'] == $value) {
                return $record['RecordId'];
            }
        }
        
        // 如果值不匹配，返回第一条记录的ID（可能值有格式差异）
        return $records['list'][0]['RecordId'];
    }

    private function execute($method, $url, $data = null)
    {
        $ch = curl_init($url);
        
        // 设置请求头
        $headers = [];
        
        if ($this->proxy) {
            // 如果需要代理设置
            curl_setopt($ch, CURLOPT_PROXY, $this->proxy);
        }
        
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        
        // 设置请求数据格式为 application/x-www-form-urlencoded
        if ($method == 'POST' && $data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        }
        
        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($errno) {
            $this->setError('Curl错误: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
        
        if ($httpCode !== 200) {
            $this->setError('HTTP错误: ' . $httpCode . ', URL: ' . $url);
            return false;
        }
        
        $decodedResponse = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->setError('JSON解析错误: ' . json_last_error_msg() . ', 响应: ' . substr($response, 0, 200));
            return false;
        }
        
        // 检查签名错误
        if (isset($decodedResponse['code']) && $decodedResponse['code'] == -1) {
            if (isset($decodedResponse['msg']) && strpos($decodedResponse['msg'], '签名错误') !== false) {
                $this->setError('API签名验证失败，请检查UID和API密钥配置');
                return false;
            }
        }
        
        return $decodedResponse;
    }
}