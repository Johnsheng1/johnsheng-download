<?php
namespace lib\dns;

use lib\DnsInterface;
use Exception;

class baidu implements DnsInterface
{
    private $AccessKeyId;
    private $SecretAccessKey;
    private $endpoint = "dns.baidubce.com";
    private $error;
    private $domain;
    private $domainid;
    private BaiduCloudClient $client;

    public function __construct($config)
    {
        $this->AccessKeyId = $config['ak'];
        $this->SecretAccessKey = $config['sk'];
        $proxy = isset($config['proxy']) ? $config['proxy'] == 1 : false;
        $this->client = new BaiduCloudClient($this->AccessKeyId, $this->SecretAccessKey, $this->endpoint, $proxy);
        $this->domain = $config['domain'];
        $this->domainid = $config['domainid'];
    }

    public function getError()
    {
        return $this->error;
    }

    public function check()
    {
        if ($this->getDomainList() != false) {
            return true;
        }
        return false;
    }

    //获取域名列表
    public function getDomainList($KeyWord = null, $PageNumber = 1, $PageSize = 20)
    {
        $query = ['name' => $KeyWord];
        $data = $this->send_request('GET', '/v1/dns/zone', $query);
        if ($data) {
            $list = [];
            foreach ($data['zones'] as $row) {
                $list[] = [
                    'DomainId' => $row['id'],
                    'Domain' => rtrim($row['name'], '.'),
                    'RecordCount' => 0,
                ];
            }
            return ['total' => count($list), 'list' => $list];
        }
        return false;
    }

    //获取解析记录列表
    public function getDomainRecords($PageNumber = 1, $PageSize = 20, $KeyWord = null, $SubDomain = null, $Value = null, $Type = null, $Line = null, $Status = null)
    {
        $query = [];
        if (!isNullOrEmpty($SubDomain)) {
            $SubDomain = strtolower($SubDomain);
            $query['rr'] = $SubDomain;
        }
        $data = $this->send_request('GET', '/v1/dns/zone/'.$this->domain.'/record', $query);
        if ($data) {
            $list = [];
            foreach ($data['records'] as $row) {
                $list[] = [
                    'RecordId' => $row['id'],
                    'Domain' => $this->domain,
                    'Name' => $row['rr'],
                    'Type' => $row['type'],
                    'Value' => $row['value'],
                    'Line' => $row['line'],
                    'TTL' => $row['ttl'],
                    'MX' => $row['priority'],
                    'Status' => $row['status'] == 'running' ? '1' : '0',
                    'Weight' => null,
                    'Remark' => $row['description'],
                    'UpdateTime' => null,
                ];
            }
            if (!isNullOrEmpty($SubDomain)) {
                $list = array_values(array_filter($list, function ($v) use ($SubDomain) {
                    return $v['Name'] == $SubDomain;
                }));
            } else {
                if (!isNullOrEmpty($KeyWord)) {
                    $list = array_values(array_filter($list, function ($v) use ($KeyWord) {
                        return strpos($v['Name'], $KeyWord) !== false || strpos($v['Value'], $KeyWord) !== false;
                    }));
                }
                if (!isNullOrEmpty($Value)) {
                    $list = array_values(array_filter($list, function ($v) use ($Value) {
                        return $v['Value'] == $Value;
                    }));
                }
                if (!isNullOrEmpty($Type)) {
                    $list = array_values(array_filter($list, function ($v) use ($Type) {
                        return $v['Type'] == $Type;
                    }));
                }
                if (!isNullOrEmpty($Status)) {
                    $list = array_values(array_filter($list, function ($v) use ($Status) {
                        return $v['Status'] == $Status;
                    }));
                }
            }
            return ['total' => count($list), 'list' => $list];
        }
        return false;
    }

    //获取子域名解析记录列表
    public function getSubDomainRecords($SubDomain, $PageNumber = 1, $PageSize = 20, $Type = null, $Line = null)
    {
        if ($SubDomain == '') $SubDomain = '@';
        return $this->getDomainRecords($PageNumber, $PageSize, null, $SubDomain, null, $Type, $Line);
    }

    //获取解析记录详细信息
    public function getDomainRecordInfo($RecordId)
    {
        $query = ['id' => $RecordId];
        $data = $this->send_request('GET', '/v1/dns/zone/'.$this->domain.'/record', $query);
        if ($data && !empty($data['records'])) {
            $data = $data['records'][0];
            return [
                'RecordId' => $data['id'],
                'Domain' => rtrim($data['zone_name'], '.'),
                'Name' => str_replace('.'.$data['zone_name'], '', $data['name']),
                'Type' => $data['type'],
                'Value' => $data['value'],
                'Line' => $data['line'],
                'TTL' => $data['ttl'],
                'MX' => $data['priority'],
                'Status' => $data['status'] == 'running' ? '1' : '0',
                'Weight' => null,
                'Remark' => $data['description'],
                'UpdateTime' => null,
            ];
        }
        return false;
    }

    //添加解析记录
    public function addDomainRecord($Name, $Type, $Value, $Line = '0', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {
        $params = [
            'rr' => $Name, 
            'type' => $this->convertType($Type), 
            'value' => $Value, 
            'line' => $Line, 
            'ttl' => intval($TTL), 
            'description' => $Remark
        ];
        
        if ($Type == 'MX') $params['priority'] = intval($MX);
        
        // 获取clientToken
        $clientToken = $this->getSid();
        $query = ['clientToken' => $clientToken];
        
        $data = $this->send_request('POST', '/v1/dns/zone/'.$this->domain.'/record', $query, $params);
        
        if ($data !== false) {
            // 添加成功后，通过查询获取新记录的ID
            // 等待一小段时间确保记录已经添加完成
            sleep(1);
            
            // 查询该子域名的所有记录
            $records = $this->getSubDomainRecords($Name, 1, 100, $Type, $Line);
            
            if ($records && !empty($records['list'])) {
                // 查找匹配的记录（值、TTL等都匹配）
                foreach ($records['list'] as $record) {
                    if ($record['Value'] == $Value && 
                        $record['Type'] == $Type && 
                        $record['TTL'] == intval($TTL) &&
                        $record['Line'] == $Line) {
                        return $record['RecordId'];  // 直接返回ID
                    }
                }
                
                // 如果没找到完全匹配的，返回第一个匹配的子域名记录
                // return $records['list'][0]['RecordId'];  // 直接返回ID
            }
            
            // 如果查询失败或没有找到记录，尝试用getDomainRecords方法再查一次
            $allRecords = $this->getDomainRecords(1, 500, null, $Name, null, $Type, $Line);
            if ($allRecords && !empty($allRecords['list'])) {
                foreach ($allRecords['list'] as $record) {
                    if ($record['Value'] == $Value && $record['Type'] == $Type) {
                        return $record['RecordId'];  // 直接返回ID
                    }
                }
            }
            
            // 如果还是没找到，返回false表示无法获取ID
            return false;
        }
        
        return false;
    }
    //修改解析记录
    public function updateDomainRecord($RecordId, $Name, $Type, $Value, $Line = '0', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {
        $params = [
            'rr' => $Name, 
            'type' => $this->convertType($Type), 
            'value' => $Value, 
            'line' => $Line, 
            'ttl' => intval($TTL), 
            'description' => $Remark
        ];
        if ($Type == 'MX') $params['priority'] = intval($MX);
        $query = ['clientToken' => $this->getSid()];
        return $this->send_request('PUT', '/v1/dns/zone/'.$this->domain.'/record/'.$RecordId, $query, $params);
    }

    //修改解析记录备注
    public function updateDomainRecordRemark($RecordId, $Remark)
    {
        $params = ['description' => $Remark];
        $query = ['clientToken' => $this->getSid()];
        return $this->send_request('PUT', '/v1/dns/zone/'.$this->domain.'/record/'.$RecordId, $query, $params);
    }

    //删除解析记录
    public function deleteDomainRecord($RecordId)
    {
        $query = ['clientToken' => $this->getSid()];
        return $this->send_request('DELETE', '/v1/dns/zone/'.$this->domain.'/record/'.$RecordId, $query);
    }

    //设置解析记录状态
    public function setDomainRecordStatus($RecordId, $Status)
    {
        $action = $Status == '1' ? 'enable' : 'disable';
        $params = [$action => ''];
        $query = ['clientToken' => $this->getSid()];
        return $this->send_request('PUT', '/v1/dns/zone/'.$this->domain.'/record/'.$RecordId, $query, $params);
    }

    //获取解析记录操作日志
    public function getDomainRecordLog($PageNumber = 1, $PageSize = 20, $KeyWord = null, $StartDate = null, $endDate = null)
    {
        return false;
    }

    //获取解析线路列表
    public function getRecordLine()
    {
        return [
            'default' => ['name' => '默认', 'parent' => null],
            'ct' => ['name' => '电信', 'parent' => null],
            'cnc' => ['name' => '联通', 'parent' => null],
            'cmnet' => ['name' => '移动', 'parent' => null],
            'edu' => ['name' => '教育网', 'parent' => null],
            'search' => ['name' => '搜索引擎(百度)', 'parent' => null],
        ];
    }

    //获取域名概览信息
    public function getDomainInfo()
    {
        $res = $this->getDomainList($this->domain);
        if ($res && !empty($res['list'])) {
            return $res['list'][0];
        }
        return false;
    }

    //获取域名最低TTL
    public function getMinTTL()
    {
        return false;
    }

    public function addDomain($Domain)
    {
        $query = ['clientToken' => $this->getSid(), 'name' => $Domain];
        $res = $this->send_request('POST', '/v1/dns/zone', null, $query);
        if ($res) {
            // 重新获取域名信息
            $config = [
                'ak' => $this->AccessKeyId,
                'sk' => $this->SecretAccessKey,
                'domain' => $Domain,
                'domainid' => '',
            ];
            $tempDns = new self($config);
            $data = $tempDns->getDomainInfo();
            if ($data) {
                return ['id' => $data['DomainId'], 'name' => $data['Domain']];
            }
        }
        return false;
    }

    private function convertType($type)
    {
        return $type;
    }

    private function send_request($method, $path, $query = null, $params = null)
    {
        try {
            return $this->client->request($method, $path, $query, $params);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return false;
        }
    }

    private function setError($message)
    {
        $this->error = $message;
        //file_put_contents('logs.txt',date('H:i:s').' '.$message."\r\n", FILE_APPEND);
    }

    private function getSid()
    {
        // 生成唯一的clientToken
        return md5(uniqid(mt_rand(), true));
    }
}

// ====================== BaiduCloudClient 客户端类 ======================

class BaiduCloudClient
{
    private $AccessKeyId;
    private $SecretAccessKey;
    private $endpoint;
    private $proxy = false;

    public function __construct($AccessKeyId, $SecretAccessKey, $endpoint, $proxy = false)
    {
        $this->AccessKeyId = $AccessKeyId;
        $this->SecretAccessKey = $SecretAccessKey;
        $this->endpoint = $endpoint;
        $this->proxy = $proxy;
    }

    /**
     * @param string $method 请求方法
     * @param string $path 请求路径
     * @param array|null $query 请求参数
     * @param array|null $params 请求体
     * @return array
     * @throws Exception
     */
    public function request($method, $path, $query = null, $params = null)
    {
        if (!empty($query)) {
            $query = array_filter($query, function ($a) { return $a !== null;});
        }
        if (!empty($params)) {
            $params = array_filter($params, function ($a) { return $a !== null;});
        }

        $time = time();
        $date = gmdate("Y-m-d\TH:i:s\Z", $time);
        $body = !empty($params) ? json_encode($params) : '';
        $headers = [
            'Host' => $this->endpoint,
            'x-bce-date' => $date,
        ];
        if ($body) {
            $headers['Content-Type'] = 'application/json';
        }

        $authorization = $this->generateSign($method, $path, $query, $headers, $time);
        $headers['Authorization'] = $authorization;

        $url = 'https://'.$this->endpoint.$path;
        if (!empty($query)) {
            $url .= '?'.http_build_query($query);
        }
        $header = [];
        foreach ($headers as $key => $value) {
            $header[] = $key.': '.$value;
        }
        return $this->curl($method, $url, $body, $header);
    }

    private function generateSign($method, $path, $query, $headers, $time)
    {
        $algorithm = "bce-auth-v1";

        // step 1: build canonical request string
        $httpRequestMethod = $method;
        $canonicalUri = $this->getCanonicalUri($path);
        $canonicalQueryString = $this->getCanonicalQueryString($query);
        [$canonicalHeaders, $signedHeaders] = $this->getCanonicalHeaders($headers);
        $canonicalRequest = $httpRequestMethod."\n"
            .$canonicalUri."\n"
            .$canonicalQueryString."\n"
            .$canonicalHeaders;

        // step 2: calculate signing key
        $date = gmdate("Y-m-d\TH:i:s\Z", $time);
        $expirationInSeconds = 1800;
        $authString = $algorithm . '/' . $this->AccessKeyId . '/' . $date . '/' . $expirationInSeconds;
        $signingKey = hash_hmac('sha256', $authString, $this->SecretAccessKey);

        // step 3: sign string
        $signature = hash_hmac("sha256", $canonicalRequest, $signingKey);

        // step 4: build authorization
        $authorization = $authString . '/' . $signedHeaders . "/" . $signature;

        return $authorization;
    }

    private function escape($str)
    {
        $search = ['+', '*', '%7E'];
        $replace = ['%20', '%2A', '~'];
        return str_replace($search, $replace, urlencode($str));
    }

    private function getCanonicalUri($path)
    {
        if (empty($path)) return '/';
        $uri = str_replace('%2F', '/', $this->escape($path));
        if (substr($uri, 0, 1) !== '/') $uri = '/' . $uri;
        return $uri;
    }

    private function getCanonicalQueryString($parameters)
    {
        if (empty($parameters)) return '';
        ksort($parameters);
        $canonicalQueryString = '';
        foreach ($parameters as $key => $value) {
            if ($key == 'authorization') continue;
            $canonicalQueryString .= '&' . $this->escape($key) . '=' . $this->escape($value);
        }
        return substr($canonicalQueryString, 1);
    }

    private function getCanonicalHeaders($oldheaders)
    {
        $headers = array();
        foreach ($oldheaders as $key => $value) {
            $headers[strtolower($key)] = trim($value);
        }
        ksort($headers);

        $canonicalHeaders = '';
        $signedHeaders = '';
        foreach ($headers as $key => $value) {
            $canonicalHeaders .= $this->escape($key) . ':' . $this->escape($value) . "\n";
            $signedHeaders .= $key . ';';
        }
        $canonicalHeaders = substr($canonicalHeaders, 0, -1);
        $signedHeaders = substr($signedHeaders, 0, -1);
        return [$canonicalHeaders, $signedHeaders];
    }

    private function curl($method, $url, $body, $header)
    {
        $ch = curl_init($url);
        if ($this->proxy) {
            curl_set_proxy($ch);
        }
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        if (!empty($body)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($errno) {
            $errmsg = curl_error($ch);
            curl_close($ch);
            throw new Exception('Curl error: ' . $errmsg);
        }
        curl_close($ch);

        if (empty($response) && $httpCode == 200) {
            return true;
        }
        $arr = json_decode($response, true);
        if ($arr) {
            if (isset($arr['code']) && isset($arr['message'])) {
                throw new Exception($arr['message']);
            } else {
                return $arr;
            }
        } else {
            throw new Exception('返回数据解析失败');
        }
    }
}