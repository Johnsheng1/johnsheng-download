<?php

namespace lib\dns;

use lib\DnsInterface;

class hydns implements DnsInterface
{
    private $apiid;
    private $apisecret;
    private $baseUrl;
    private $typeList = [1 => 'A', 2 => 'NS', 5 => 'CNAME', 15 => 'MX', 16 => 'TXT', 28 => 'AAAA', 33 => 'SRV', 257 => 'CAA', 256 => 'URL转发'];
    private $error;
    private $domain;
    private $domainid;
    private $proxy;
    private $token;

    public function __construct($config)
    {
        $this->apiid = $config['ak'] ?? '';          // API URL
        $this->apisecret = $config['sk'] ?? '';      // API Token
        $this->domain = $config['domain'] ?? '';
        $this->domainid = $config['domainid'] ?? '';
        $this->proxy = isset($config['proxy']) ? $config['proxy'] == 1 : false;
        $this->baseUrl = rtrim($this->apiid, '/');
    }

    public function getError()
    {
        return $this->error;
    }

    private function setError($message)
    {
        $this->error = $message;
    }

    public function check()
    {
        if ($this->getDomainList() !== false) {
            return true;
        }
        return false;
    }

    // 获取域名列表
    public function getDomainList($KeyWord = null, $PageNumber = 1, $PageSize = 20)
    {
        $url = $this->baseUrl . '/api/domain_name/api/domain_name/getdomainnamelist';
        $data = ['token' => $this->apisecret];
        
        $response = $this->execute('POST', $url, $data);
        
        if (!$response || !isset($response['data']) || !is_array($response['data'])) {
            $this->setError('获取域名列表失败：响应格式错误');
            return false;
        }
        
        $list = [];
        foreach ($response['data'] as $row) {
            if (isset($row['domainName']) && isset($row['id'])) {
                $list[] = [
                    'DomainId' => $row['id'],
                    'Domain' => $row['domainName'],
                    'RecordCount' => 0,
                ];
            }
        }
        
        return ['total' => count($list), 'list' => $list];
    }

    // 获取解析记录列表
    public function getDomainRecords($PageNumber = 1, $PageSize = 20, $KeyWord = null, $SubDomain = null, $Value = null, $Type = null, $Line = null, $Status = null)
    {
        // HyDNS API 可能不支持获取记录列表，返回空数组
        return ['total' => 0, 'list' => []];
    }

    // 获取子域名解析记录列表
    public function getSubDomainRecords($SubDomain, $PageNumber = 1, $PageSize = 20, $Type = null, $Line = null)
    {
        // HyDNS API 不支持获取记录列表
        return ['total' => 0, 'list' => []];
    }

    // 获取解析记录详细信息
    public function getDomainRecordInfo($RecordId)
    {
        return false;
    }

    // 添加解析记录
    public function addDomainRecord($Name, $Type, $Value, $Line = 'tele', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {
        // 首先需要获取域名的销售点信息
        $monthsId = $this->getDomainSellingPoints($this->domainid);
        if (!$monthsId) {
            $this->setError('无法获取域名销售点信息');
            return false;
        }
        
        $url = $this->baseUrl . '/api/domain_name/api/domain_name/addanalysis';

        $params = [
            'token' => $this->apisecret,
            'name' => $Name,
            'type' => $Type,
            'line' => '默认',
            'value' => $Value,
            'monthsId' => $monthsId,
            'domainNameId' => $this->domainid
        ];
  
        
        $response = $this->execute('POST', $url, $params);
          
        if ($response && isset($response['code']) && $response['code'] == 200) {
            return $response['data'] ?? '';
        } else {
            $this->setError($response['msg'] ?? '添加记录失败');
            return false;
        }
    }

    // 修改解析记录
    public function updateDomainRecord($RecordId, $Name, $Type, $Value, $Line = '0', $TTL = 600, $MX = 1, $Weight = null, $Remark = null)
    {
        $url = $this->baseUrl . '/api/domain_name/api/domain_name/updateanalysis';
    
        
        $params = [
            'id' => $RecordId,
            'token' => $this->apisecret,
            'name' => $Name,
            'type' => $Type,
            'line' => '默认',
            'value' => $Value
        ];
        
        $response = $this->execute('POST', $url, $params);
        
        if ($response && isset($response['code']) && $response['code'] == 200) {
            return true;
        } else {
            $this->setError($response['msg'] ?? '更新记录失败');
            return false;
        }
    }

    // 修改解析记录备注
    public function updateDomainRecordRemark($RecordId, $Remark)
    {
        // HyDNS API 不支持修改备注
        return false;
    }

    // 删除解析记录
    public function deleteDomainRecord($RecordId)
    {
        $url = $this->baseUrl . '/api/domain_name/api/domain_name/delete';
        
        $params = [
            'id' => $RecordId,
            'token' => $this->apisecret,
            'domainNameId' => $this->domainid
        ];
        
        $response = $this->execute('POST', $url, $params);
        
        if ($response && isset($response['code']) && $response['code'] == 200) {
            return true;
        } else {
            $this->setError($response['msg'] ?? '删除记录失败');
            return false;
        }
    }

    // 设置解析记录状态
    public function setDomainRecordStatus($RecordId, $Status)
    {
        // HyDNS API 可能不支持记录状态切换
        $this->setError('HyDNS 不支持记录状态切换功能');
        return false;
    }

    // 获取解析记录操作日志
    public function getDomainRecordLog($PageNumber = 1, $PageSize = 20, $KeyWord = null, $StartDate = null, $endDate = null)
    {
        return false;
    }

    // 获取解析线路列表
    public function getRecordLine()
    {
        // HyDNS API 可能不支持线路选择，返回默认线路
        return ['默认' => ['name' => '默认线路', 'parent' => null]];
    }

    // 获取域名信息
    public function getDomainInfo()
    {
        // HyDNS API 可能没有直接获取域名信息的接口
        return false;
    }

    // 获取域名最低TTL
    public function getMinTTL()
    {
        // HyDNS API 可能不支持获取最低TTL
        return 600; // 返回默认值
    }

    // 添加域名（可能需要特定的API）
    public function addDomain($Domain)
    {
        $this->setError('HyDNS 不支持通过API添加域名');
        return false;
    }

    // 续费DNS记录
    public function renewRecord($domain, $recordId, $renewData = [])
    {
        try {
            // 获取monthsId
            $monthsId = $this->getMonthsIdFromPackage($renewData);
            
            $url = $this->baseUrl . '/api/domain_name/api/domain_name/renewal';
            
            $params = [
                'token' => $this->apisecret,
                'id' => $recordId,
                'monthsId' => $monthsId
            ];
            
            $response = $this->execute('POST', $url, $params);
            
            if ($response && isset($response['code']) && $response['code'] == 200) {
                return [
                    'success' => true,
                    'local_renew' => false,
                    'message' => 'API续费成功',
                    'data' => $response['data'] ?? []
                ];
            } else {
                $errorMsg = 'API续费失败';
                if (isset($response['msg'])) {
                    $errorMsg .= ': ' . $response['msg'];
                }
                $this->setError($errorMsg);
                return [
                    'success' => false,
                    'local_renew' => true,
                    'message' => $errorMsg
                ];
            }
            
        } catch (\Exception $e) {
            $this->setError('HyDNS续费API异常: ' . $e->getMessage());
            
            return [
                'success' => false,
                'local_renew' => true,
                'message' => 'API续费异常: ' . $e->getMessage()
            ];
        }
    }

    // 私有方法

    private function convertType($type)
    {
        $typeList = array_flip($this->typeList);
        return isset($typeList[$type]) ? $typeList[$type] : 1; // 默认A记录
    }

    private function getDomainSellingPoints($domainId)
    {
        $url = $this->baseUrl . '/api/domain_name/api/domain_name/getdomainnamesellingpoints';
        $params = [
            'id' => $domainId,
            'token' => $this->apisecret
        ];
        
        $response = $this->execute('POST', $url, $params);
        
        if ($response && isset($response['data'][0]['id'])) {
            return $response['data'][0]['id'];
        } else {
            $this->setError('无法获取域名销售点信息');
            return false;
        }
    }

    private function getMonthsIdFromPackage($renewData)
    {
        if (!empty($renewData)) {
            $packageInfo = $renewData['package_info'] ?? [];
            $sortOrder = $packageInfo['sort_order'] ?? 0;
            switch ($sortOrder) {
                case 0: return '1';
                case 1: return '2';
                case 2: return '3';
                default: return '1';
            }
        }
        
        return '1'; // 默认monthsId
    }

    private function execute($method, $url, $params = null)
    {
        $header = ['Content-Type: application/json; charset=utf-8'];
        
        $ch = curl_init($url);
        
        if ($this->proxy) {
            // 如果需要代理设置，这里可以添加
            // curl_setopt($ch, CURLOPT_PROXY, ...);
        }
        
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        
        if ($method == 'POST' || $method == 'PUT') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        }
        
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($errno) {
            $this->setError('Curl error: ' . curl_error($ch));
            curl_close($ch);
            return false;
        }
        
        curl_close($ch);
        
        if ($httpCode !== 200) {
            $this->setError('HTTP Error: ' . $httpCode);
            return false;
        }
        
        $decodedResponse = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->setError('JSON解析错误: ' . json_last_error_msg());
            return false;
        }
        
        return $decodedResponse;
    }
}