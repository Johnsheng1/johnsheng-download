ALTER TABLE `pre_url` 
ADD COLUMN `remark` TEXT COMMENT '备注' AFTER `exclusive_prices`,
ADD COLUMN `description` TEXT COMMENT '说明' AFTER `remark`;

-- 更新版本号数据库
INSERT INTO `pre_config` (`k`, `v`) 
VALUES ('sqlupdate', '2025-12-13 00:00:00') 
ON DUPLICATE KEY UPDATE `v` = '2025-12-13 00:00:00';