-- 站内信表
CREATE TABLE `pre_messages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` bigint(20) UNSIGNED NOT NULL COMMENT '用户ID',
  `sender_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT '发送者ID（0=系统消息）',
  `title` varchar(255) NOT NULL COMMENT '消息标题',
  `content` text NOT NULL COMMENT '消息内容',
  `type` text NOT NULL COMMENT '消息类型',
  `is_read` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否已读：0=未读，1=已读',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_uid_is_read` (`uid`, `is_read`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户站内信表';



-- 通知配置表
CREATE TABLE `pre_notice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `type` text NOT NULL COMMENT '通知类型',
  `time` text NOT NULL COMMENT '通知时机',
  `message` int(2) NOT NULL COMMENT '站内信 0关闭 1开启',
  `email` int(2) NOT NULL COMMENT '邮箱',
  `subject` text COMMENT '通知标题',
  `content` text COMMENT '通知内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='用户站内信表';


ALTER TABLE `pre_notice` AUTO_INCREMENT = 1;

INSERT INTO `pre_notice` (`id`, `type`, `time`, `message`, `email`, `subject`, `content`) VALUES
(1, '用户注册成功通知', '用户注册成功后', 1, 1, '用户添加解析', NULL),
(2, '域名解析恢复通知', '域名解析暂停恢复通知', 1, 1, '域名解析恢复通知', NULL),
(3, '登录成功通知', '	\r\n用户登录成功时', 1, 1, '账号登录提醒', NULL),
(4, '域名解析过期删除通知', '	\r\n域名解析过期删除时', 1, 1, '域名解析到期通知', NULL),
(5, '域名解析暂停通知', '域名解析暂停时', 1, 1, '域名解析暂停通知', NULL),
(6, '添加解析通知', '添加域名解析时', 1, 1, '域名解析记录添加提醒', NULL),
(7, '修改解析通知', '修改域名解析时', 1, 1, '域名解析记录修改通知', NULL),
(8, '删除解析通知', '用户删除解析时', 1, 1, '域名解析记录删除通知', NULL);


-- 异常解析表 

CREATE TABLE `pre_dns_diff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL COMMENT '用户ID',
  `domain` varchar(255) NOT NULL COMMENT '域名',
  `type` tinyint(4) NOT NULL COMMENT '1=本地有云没有,2=云有本地没有',
  `name` varchar(100) NOT NULL COMMENT '主机记录',
  `record_type` varchar(10) NOT NULL COMMENT 'A/CNAME等',
  `value` varchar(255) NOT NULL COMMENT '记录值',
  `cloud_record_id` varchar(50) DEFAULT NULL COMMENT '云解析的RecordId',
  `remark` text COMMENT '处理方式',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT '0' COMMENT '0=未处理,1=已处理',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8mb4;


-- 更新版本号数据库
INSERT INTO `pre_config` (`k`, `v`) 
VALUES ('sqlupdate', '2025-12-23:00:00') 
ON DUPLICATE KEY UPDATE `v` = '2025-12-23 00:00:00';



