ALTER TABLE`pre_record` 
ADD COLUMN `stop` varchar(255) NULL COMMENT '暂停解析前记录' AFTER `TTL`;

-- 更新版本号数据库
INSERT INTO `pre_config` (`k`, `v`) 
VALUES ('sqlupdate', '2025-12-16:00:00') 
ON DUPLICATE KEY UPDATE `v` = '2025-12-16 00:00:00';