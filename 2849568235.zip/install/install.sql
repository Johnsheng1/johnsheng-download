
-- https://www.52hyjs.com
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


-- --------------------------------------------------------

--
-- 表的结构 `pre_cache`
--

CREATE TABLE `pre_cache` (
  `k` varchar(32) NOT NULL,
  `v` longtext,
  `expire` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_config`
--

CREATE TABLE `pre_config` (
  `k` varchar(32) NOT NULL,
  `v` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pre_config`
--

INSERT INTO `pre_config` (`k`, `v`) VALUES
('admin_pwd', '123456'),
('admin_user', 'admin'),
('description', '幻影二级域名分发系统'),
('gg', '本站提供二级域名用于测试、学习等，请勿将二级域名用于一切非法用途，一切责任自负！3元解析一次，用到域名到期！需要积分请联系QQ：123456789'),
('icoimg', '/assets/images/favicon.ico'),
('icp', '备案号'),
('keywords', '幻影二级域名分发系统'),
('logoimg', '/assets/images/logo.png'),
('qq', '419437697'),
('qun', 'https://qm.qq.com/q/Ot9wmFGNC8'),
('recordgg', '绝对禁止解析列如:代刷 ，外挂，侵权视频，侵权游戏，侵权版权，av，灰产，盲盒，假客服，黄赌毒诈骗，支付，码支付，商城等违法违规产品，如有违法违规 本平台会无条件删除所有解析永久封号，购买的积分无法退款，域名一经解析不支持更换域名以及修改前缀。解析即代表同意以上规则，不同意请别购买。'),
('sms_tpl_edit', '尊敬的用户，您本次验证码为：{code}，请勿将验证码提供给他人，请尽快完成操作。若非你本人操作，请忽略。'),
('template', 'mb11'),
('title', '幻影二级域名分发系统'),
('urlkeywords', '幻影,网络科技'),
('workorder_type', '解析问题|域名无法使用|充值没到账');

-- --------------------------------------------------------

--
-- 表的结构 `pre_detailed`
--

CREATE TABLE `pre_detailed` (
  `id` int(11) NOT NULL,
  `uid` varchar(150) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `before_change` decimal(10,2) NOT NULL DEFAULT '0.00',
  `after_change` decimal(10,2) NOT NULL DEFAULT '0.00',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `date` datetime NOT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_dns`
--

CREATE TABLE `pre_dns` (
  `id` int(11) NOT NULL,
  `dns` text,
  `config_name` varchar(50) DEFAULT NULL,
  `created_name` varchar(50) DEFAULT NULL,
  `config` text,
  `created` text,
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `add_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_email`
--

CREATE TABLE `pre_email` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `addtime` datetime NOT NULL,
  `endtime` datetime NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_gonggao`
--

CREATE TABLE `pre_gonggao` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  `domain` varchar(150) DEFAULT NULL,
  `content` text,
  `color` varchar(10) DEFAULT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;


-- --------------------------------------------------------

--
-- 表的结构 `pre_group`
--

CREATE TABLE `pre_group` (
  `id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `recode` text,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `zhekou` varchar(50) DEFAULT NULL,
  `endtime` varchar(20) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pre_group`
--

INSERT INTO `pre_group` (`id`, `name`, `recode`, `price`, `zhekou`, `endtime`, `active`, `date`) VALUES
(100, '默认用户组', 'A,CNAME,AAAA,NS,MX,SRV,TXT,CAA,REDIRECT_URL,FORWARD_URL', '0.00', '100', '默认用户组不可删除可修改', 1, '2025-12-04 17:39:57');

-- --------------------------------------------------------

--
-- 表的结构 `pre_icptype`
--

CREATE TABLE `pre_icptype` (
  `id` int(11) NOT NULL,
  `type` text NOT NULL COMMENT '备案类型',
  `data` varchar(255) DEFAULT NULL COMMENT '分类介绍',
  `sort` int(10) DEFAULT NULL COMMENT '分类权重'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='备案类型表';

--
-- 转存表中的数据 `pre_icptype`
--

INSERT INTO `pre_icptype` (`id`, `type`, `data`, `sort`) VALUES
(4, '阿里云备案', '阿里云备案', 1),
(5, '腾讯云企业备案', '腾讯云企业备案', 0);

-- --------------------------------------------------------

--
-- 表的结构 `pre_illegal_record`
--

CREATE TABLE `pre_illegal_record` (
  `id` int(11) NOT NULL COMMENT '主键',
  `record_id` int(11) NOT NULL COMMENT '解析ID',
  `username` varchar(64) NOT NULL COMMENT '用户名',
  `url` varchar(255) NOT NULL COMMENT '主域名',
  `record` varchar(255) NOT NULL COMMENT '解析记录',
  `keyword` varchar(100) NOT NULL COMMENT '命中关键词',
  `context` text COMMENT '违规片段',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '检测时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='违规记录表';

-- --------------------------------------------------------

--
-- 表的结构 `pre_link`
--

CREATE TABLE `pre_link` (
  `id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `domain` varchar(150) DEFAULT NULL,
  `img` text,
  `content` text,
  `link_href` tinyint(2) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- 表的结构 `pre_log`
--

CREATE TABLE `pre_log` (
  `id` int(11) NOT NULL,
  `uid` varchar(150) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `browser` varchar(225) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_order`
--

CREATE TABLE `pre_order` (
  `trade_no` varchar(64) NOT NULL,
  `out_trade_no` varchar(150) NOT NULL,
  `api_trade_no` varchar(150) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `tid` int(11) NOT NULL,
  `uid` int(11) UNSIGNED NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `money` varchar(32) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `buyer` varchar(30) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `date` date DEFAULT NULL,
  `domain` varchar(64) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- 表的结构 `pre_other`
--

CREATE TABLE `pre_other` (
  `trade_no` varchar(64) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `channel` varchar(10) DEFAULT NULL,
  `zid` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `tid` int(11) NOT NULL,
  `input` text NOT NULL,
  `num` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `money` varchar(32) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `user` varchar(32) DEFAULT NULL,
  `inviteid` int(11) UNSIGNED DEFAULT NULL,
  `domain` varchar(64) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_record`
--

CREATE TABLE `pre_record` (
  `id` int(11) NOT NULL,
  `uid` varchar(225) DEFAULT NULL,
  `user` varchar(150) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(225) DEFAULT NULL,
  `type` varchar(225) DEFAULT NULL,
  `line` varchar(150) DEFAULT NULL,
  `value` varchar(225) DEFAULT NULL,
  `TTL` varchar(150) DEFAULT NULL,
  `stop` varchar(255) DEFAULT NULL COMMENT '暂停解析前记录',
  `data` text,
  `status` int(1) NOT NULL DEFAULT '1',
  `add_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `record_type` int(3) DEFAULT NULL COMMENT '解析类型1 二级 2整租'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_regcode`
--

CREATE TABLE `pre_regcode` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `type` int(1) NOT NULL DEFAULT '0',
  `code` varchar(32) NOT NULL,
  `to` varchar(32) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `errcount` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_sendlog`
--

CREATE TABLE `pre_sendlog` (
  `id` int(11) NOT NULL,
  `type` int(1) DEFAULT NULL COMMENT '1 短信  2 邮箱',
  `uid` varchar(150) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `browser` varchar(225) DEFAULT NULL,
  `data` text,
  `status` int(1) DEFAULT NULL COMMENT '1发送成功  0 发送失败'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_shop`
--

CREATE TABLE `pre_shop` (
  `id` int(11) NOT NULL,
  `dns` text,
  `user_uid` int(11) DEFAULT NULL,
  `url_id` varchar(50) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `endtime` datetime NOT NULL COMMENT '到期时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_url`
--

CREATE TABLE `pre_url` (
  `id` int(11) NOT NULL,
  `dns_key` varchar(32) NOT NULL COMMENT '秘钥ID',
  `domain_id` varchar(50) NOT NULL COMMENT '域名id',
  `domain` varchar(50) NOT NULL COMMENT '域名',
  `icptype` int(1) DEFAULT '0' COMMENT '备案类型',
  `icp` varchar(50) DEFAULT NULL COMMENT 'icp备案号',
  `domain_type` int(1) NOT NULL DEFAULT '0' COMMENT '上架类型 1二级 2整租',
  `second_count` int(10) DEFAULT '0' COMMENT '二级解析次数',
  `exclusive_count` int(10) DEFAULT NULL COMMENT '整租次数',
  `add_time` datetime NOT NULL,
  `state` int(1) DEFAULT NULL COMMENT '域名状态0正常1下架2整租已售',
  `files` varchar(255) DEFAULT NULL COMMENT 'ssl证书地址',
  `sort` int(10) DEFAULT NULL COMMENT '权重',
  `cert_force` varchar(255) DEFAULT NULL COMMENT '是否实名0无需 1需要',
  `qianzhui` varchar(255) DEFAULT NULL COMMENT '保留前缀',
  `remark` text COMMENT '备注',
  `description` text COMMENT '说明',
  `second_prices` text COMMENT '二级分发价格',
  `exclusive_prices` text COMMENT '整租价格'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_user`
--

CREATE TABLE `pre_user` (
  `uid` int(11) NOT NULL,
  `user` varchar(16) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `qq` varchar(20) DEFAULT NULL,
  `rmb` decimal(10,2) NOT NULL DEFAULT '0.00',
  `group` int(11) NOT NULL DEFAULT '100',
  `email` varchar(32) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `dlip` varchar(15) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL COMMENT '会员组到期时间',
  `cert` tinyint(4) NOT NULL DEFAULT '0' COMMENT '实名状态 1 未实名 2 已实名',
  `certtype` tinyint(4) NOT NULL DEFAULT '0',
  `certmethod` tinyint(4) NOT NULL DEFAULT '0',
  `certno` varchar(18) DEFAULT NULL COMMENT '身份证号',
  `certname` varchar(32) DEFAULT NULL COMMENT '姓名',
  `certtime` datetime DEFAULT NULL COMMENT '实名时间',
  `certtoken` varchar(64) DEFAULT NULL,
  `certcorpno` varchar(30) DEFAULT NULL,
  `certcorpname` varchar(80) DEFAULT NULL,
  `cert_cause` text,
  `token` text COMMENT 'api接口秘钥',
  `apikey` text NOT NULL,
  `qq_uid` varchar(32) NOT NULL,
  `wx_uid` varchar(32) NOT NULL,
  `alipay_uid` varchar(32) NOT NULL,
  `boss` varchar(150) DEFAULT NULL COMMENT '上级邀请ID',
  `date` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_userlog`
--

CREATE TABLE `pre_userlog` (
  `id` int(11) NOT NULL,
  `uid` varchar(150) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `browser` varchar(225) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_workorder`
--

CREATE TABLE `pre_workorder` (
  `id` int(11) UNSIGNED NOT NULL,
  `uid` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `type` int(1) UNSIGNED NOT NULL DEFAULT '0',
  `orderid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `picurl` varchar(150) DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 站内信表
CREATE TABLE `pre_messages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` bigint(20) UNSIGNED NOT NULL COMMENT '用户ID',
  `sender_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0 COMMENT '发送者ID（0=系统消息）',
  `title` varchar(255) NOT NULL COMMENT '消息标题',
  `content` text NOT NULL COMMENT '消息内容',
  `type` text NOT NULL COMMENT '消息类型',
  `is_read` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否已读：0=未读，1=已读',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_uid_is_read` (`uid`, `is_read`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户站内信表';

-- 通知配置表
CREATE TABLE `pre_notice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `type` text NOT NULL COMMENT '通知类型',
  `time` text NOT NULL COMMENT '通知时机',
  `message` int(2) NOT NULL COMMENT '站内信 0关闭 1开启',
  `email` int(2) NOT NULL COMMENT '邮箱',
  `subject` text COMMENT '通知标题',
  `content` text COMMENT '通知内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='用户站内信表';

ALTER TABLE `pre_notice` AUTO_INCREMENT = 1;

INSERT INTO `pre_notice` (`id`, `type`, `time`, `message`, `email`, `subject`, `content`) VALUES
(1, '用户注册成功通知', '用户注册成功后', 1, 1, '用户添加解析', NULL),
(2, '域名解析恢复通知', '域名解析暂停恢复通知', 1, 1, '域名解析恢复通知', NULL),
(3, '登录成功通知', '	\r\n用户登录成功时', 1, 1, '账号登录提醒', NULL),
(4, '域名解析过期删除通知', '	\r\n域名解析过期删除时', 1, 1, '域名解析到期通知', NULL),
(5, '域名解析暂停通知', '域名解析暂停时', 1, 1, '域名解析暂停通知', NULL),
(6, '添加解析通知', '添加域名解析时', 1, 1, '域名解析记录添加提醒', NULL),
(7, '修改解析通知', '修改域名解析时', 1, 1, '域名解析记录修改通知', NULL),
(8, '删除解析通知', '用户删除解析时', 1, 1, '域名解析记录删除通知', NULL);

-- 异常解析表 

CREATE TABLE `pre_dns_diff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL COMMENT '用户ID',
  `domain` varchar(255) NOT NULL COMMENT '域名',
  `type` tinyint(4) NOT NULL COMMENT '1=本地有云没有,2=云有本地没有',
  `name` varchar(100) NOT NULL COMMENT '主机记录',
  `record_type` varchar(10) NOT NULL COMMENT 'A/CNAME等',
  `value` varchar(255) NOT NULL COMMENT '记录值',
  `cloud_record_id` varchar(50) DEFAULT NULL COMMENT '云解析的RecordId',
  `remark` text COMMENT '处理方式',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT '0' COMMENT '0=未处理,1=已处理',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8mb4;

--
-- 转储表的索引
--

--
-- 表的索引 `pre_cache`
--
ALTER TABLE `pre_cache`
  ADD PRIMARY KEY (`k`);

--
-- 表的索引 `pre_config`
--
ALTER TABLE `pre_config`
  ADD PRIMARY KEY (`k`);

--
-- 表的索引 `pre_detailed`
--
ALTER TABLE `pre_detailed`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_dns`
--
ALTER TABLE `pre_dns`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_email`
--
ALTER TABLE `pre_email`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_gonggao`
--
ALTER TABLE `pre_gonggao`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_group`
--
ALTER TABLE `pre_group`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_icptype`
--
ALTER TABLE `pre_icptype`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_illegal_record`
--
ALTER TABLE `pre_illegal_record`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_link`
--
ALTER TABLE `pre_link`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_log`
--
ALTER TABLE `pre_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_order`
--
ALTER TABLE `pre_order`
  ADD PRIMARY KEY (`trade_no`);

--
-- 表的索引 `pre_other`
--
ALTER TABLE `pre_other`
  ADD PRIMARY KEY (`trade_no`);

--
-- 表的索引 `pre_record`
--
ALTER TABLE `pre_record`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_regcode`
--
ALTER TABLE `pre_regcode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`to`,`type`);

--
-- 表的索引 `pre_sendlog`
--
ALTER TABLE `pre_sendlog`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_shop`
--
ALTER TABLE `pre_shop`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_url`
--
ALTER TABLE `pre_url`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_user`
--
ALTER TABLE `pre_user`
  ADD PRIMARY KEY (`uid`);

--
-- 表的索引 `pre_userlog`
--
ALTER TABLE `pre_userlog`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `pre_workorder`
--
ALTER TABLE `pre_workorder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `zid` (`uid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `pre_detailed`
--
ALTER TABLE `pre_detailed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- 使用表AUTO_INCREMENT `pre_dns`
--
ALTER TABLE `pre_dns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `pre_email`
--
ALTER TABLE `pre_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `pre_gonggao`
--
ALTER TABLE `pre_gonggao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `pre_group`
--
ALTER TABLE `pre_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- 使用表AUTO_INCREMENT `pre_icptype`
--
ALTER TABLE `pre_icptype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用表AUTO_INCREMENT `pre_illegal_record`
--
ALTER TABLE `pre_illegal_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=6;

--
-- 使用表AUTO_INCREMENT `pre_link`
--
ALTER TABLE `pre_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pre_log`
--
ALTER TABLE `pre_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- 使用表AUTO_INCREMENT `pre_record`
--
ALTER TABLE `pre_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- 使用表AUTO_INCREMENT `pre_regcode`
--
ALTER TABLE `pre_regcode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `pre_sendlog`
--
ALTER TABLE `pre_sendlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- 使用表AUTO_INCREMENT `pre_shop`
--
ALTER TABLE `pre_shop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `pre_url`
--
ALTER TABLE `pre_url`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- 使用表AUTO_INCREMENT `pre_user`
--
ALTER TABLE `pre_user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `pre_userlog`
--
ALTER TABLE `pre_userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- 使用表AUTO_INCREMENT `pre_workorder`
--
ALTER TABLE `pre_workorder`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
