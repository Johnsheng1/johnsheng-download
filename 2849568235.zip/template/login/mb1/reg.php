<?php
/**
 * 注册
**/
include("../includes/common.php");
$title="用户注册";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $conf["title"] ?> - <?php echo $title ?></title>
    <meta name="keywords" content="<?php echo $conf["keywords"] ?>"/>
    <meta name="description" content="<?php echo $conf["description"] ?>"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link href="../favicon.ico" rel="icon">
    <link rel="stylesheet" href="<?=TEMPLATE;?>/assets/libs/layui/css/layui.css"/>
    <link rel="stylesheet" href="<?=TEMPLATE;?>/assets/module/admin.css?v=318">
    <style>
        html{
            height: 100%;
        }
        .login-wrapper {
            max-width: 420px;
            padding: 20px;
            margin: 0 auto;
            position: relative;
            box-sizing: border-box;
            z-index: 2;
        }

        .login-wrapper > .layui-form {
            padding: 25px 30px;
            background-color: #fff;
            box-shadow: 0 3px 6px -1px rgba(0, 0, 0, 0.19);
            box-sizing: border-box;
            border-radius: 4px;
        }

        .login-wrapper > .layui-form > h2 {
            color: #333;
            font-size: 18px;
            text-align: center;
            margin-bottom: 25px;
        }

        .login-wrapper > .layui-form > .layui-form-item {
            margin-bottom: 25px;
            position: relative;
        }

        .login-wrapper > .layui-form > .layui-form-item:last-child {
            margin-bottom: 0;
        }

        .login-wrapper > .layui-form > .layui-form-item > .layui-input {
            height: 40px;
            line-height: 1.5;
            border-radius: 4px !important;
        }

        .login-wrapper .layui-input-icon-group > .layui-input {
            padding-left: 40px;
        }

        .login-wrapper .layui-input-icon-group > .layui-icon {
            width: 40px;
            height: 40px;
            line-height: 40px;
            font-size: 18px;
            color: #909399;
            position: absolute;
            left: 0;
            top: 0;
            text-align: center;
        }

        .login-wrapper > .layui-form > .layui-form-item.login-captcha-group {
            padding-right: 135px;
        }

        .login-wrapper > .layui-form > .layui-form-item.login-captcha-group > .login-captcha {
            height: 46px;
            width: 120px;
            cursor: pointer;
            box-sizing: border-box;
            border: 1px solid #e6e6e6;
            border-radius: 4px !important;
            position: absolute;
            right: 0;
            top: 0;
        }

        .login-wrapper > .layui-form > .layui-form-item > .layui-form-checkbox {
            margin: 0 !important;
            padding-left: 25px;
        }

        .login-wrapper > .layui-form > .layui-form-item > .layui-form-checkbox > .layui-icon {
            width: 15px !important;
            height: 15px !important;
        }

        .login-wrapper > .layui-form .sf {
            display: inline-block;
            margin-bottom: 0;
            font-weight: 400;
            text-align: center;
            vertical-align: middle;
            touch-action: manipulation;
            cursor: pointer;
            background-image: none;
            border: 1px solid transparent;
            white-space: nowrap;
            user-select: none;
            height: 40px;
            padding: 0 15px;
            font-size: 16px;
            border-radius: 4px;
            transition: color .2s linear,background-color .2s linear,border .2s linear,box-shadow .2s linear;
            color: #fff;
            background-color: #fff;
            border-color: #dcdee2;
            line-height: 1.5;
            border-radius: 4px !important;
            background-color: #2d8cf0;
            border-color: #2d8cf0;
        }
        .login-wrapper > .layui-form .sf2 {
            display: inline-block;
            margin-bottom: 0;
            font-weight: 400;
            text-align: center;
            vertical-align: middle;
            touch-action: manipulation;
            cursor: pointer;
            background-image: none;
            border: 1px solid transparent;
            white-space: nowrap;
            user-select: none;
            height: 40px;
            padding: 0 15px;
            font-size: 16px;
            border-radius: 4px;
            transition: color .2s linear,background-color .2s linear,border .2s linear,box-shadow .2s linear;
            color: #000000;
            background-color: #fff;
            border-color: #dcdee2;
            line-height: 1.5;
            border-radius: 4px !important;
        }

        .login-wrapper > .layui-form > .layui-form-item.login-oauth-group > a > .layui-icon {
            font-size: 26px;
        }

        @media screen and (min-height: 550px) {
            .login-wrapper {
                margin: -250px auto 0;
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                width: 100%;
            }
        }

        .layui-btn {
            background-color: #5FB878;
            border-color: #5FB878;
        }

        .layui-link {
            color: #5FB878 !important;
        }

        .layer-get-code > p {
            color: #666;
            font-size: 16px;
        }

        .layer-get-code > .lay-code-group > .layui-input {
            border-radius: 0;
            height: 46px;
            line-height: 46px;
            background-color: transparent;
            border-color: rgba(111, 121, 122, 0.3);
        }

        .layer-get-code > .lay-code-group > img {
            position: absolute;
            right: 0;
            top: 0;
            height: 46px;
            width: 120px;
            box-sizing: border-box;
            cursor: pointer;
        }

        .logo {
            width: 60px !important;
            margin-top: 10px !important;
            margin-bottom: 10px !important;
            margin-left: 20px !important;
        }
        .title {
            font-size: 30px !important;
            font-weight: 550 !important;
            margin-left: 20px !important;
            color: #3492ed !important;
            display: inline-block !important;
            height: 60px !important;
            line-height: 60px !important;
            margin-top: 10px !important;
            position: absolute !important;
        }

        .desc {
            width: 100% !important;
            text-align: center !important;
            color: gray !important;
            height: 60px !important;
            line-height: 60px !important;
        }
        .page-account-other {
            margin: 24px 0;
            text-align: left;
        }
        .page-account-other img {
            width: 24px;
            margin-left: 16px;
            cursor: pointer;
            vertical-align: middle;
            opacity: .7;
            transition: all .2s ease-in-out;
        }

        .imgbj{
            width: auto;
            height: auto;
            /*opacity: 0.6;*/
            top: 0;
            left: 0;
            z-index: -1;
            position: fixed;
            background-size: cover;
        }
        .imgc{
            background-size: 100% 100%;
            background-repeat: repeat;
            top: 0;
            position: fixed;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

    </style>
</head>
<div class="imgc"></div>
<img class="imgbj" src="<?=TEMPLATE;?>/assets/images/background.svg">
<div class="login-wrapper layui-anim layui-anim-scale layui-hide">
    <form class="layui-form layui-card-body" style="padding: 28px 15px;box-sizing: border-box;min-height: 126px;opacity: 0.95">
        <div class="layui-form-item">
            <img class="logo" src="/assets/images/favicon.ico" />
            <div class="title">用户账号注册</div>
            <div class="desc">
            <?=$conf['name']?> 分 发 系 统 用 户 管 理 中 心
            </div>
        </div>
        <div class="layui-form-item layui-input-icon-group">
            <i class="layui-icon layui-icon-username"></i>
            <input class="layui-input" name="user" placeholder="请输入登录账号" autocomplete="off"
                   lay-verType="tips" lay-verify="required" >
        </div>
        <div class="layui-form-item layui-input-icon-group">
            <i class="layui-icon layui-icon-password"></i>
            <input class="layui-input" name="pwd" placeholder="请输入登录密码" type="password"
                   lay-verType="tips" lay-verify="required" autocomplete="off">
        </div>
        <div class="layui-form-item layui-input-icon-group">
            <i class="layui-icon layui-icon-email"></i>
            <input class="layui-input" name="email" placeholder="请输入邮箱" autocomplete="off"
                   lay-verType="tips" lay-verify="required" autocomplete="off">
        </div>
        <div class="layui-form-item layui-input-icon-group">
            <i class="layui-icon layui-icon-login-qq"></i>
            <input type="number" class="layui-input" name="qq" placeholder="请输入QQ" autocomplete="off"
                   lay-verType="tips" lay-verify="required" autocomplete="off">
        </div>
        <div class="layui-form-item layui-input-icon-group login-captcha-group">
            <i class="layui-icon layui-icon-auz"></i>
            <input type="text" class="layui-input" name="code" placeholder="请输入验证码" autocomplete="off" lay-verType="tips">
			<img class="login-captcha" alt=""/>
        </div>
        <div class="layui-form-item">
            <a href="login.php" class="layui-link pull-right">返回登录</a>
        </div>
        <div class="layui-form-item">
            <button class="layui-btn layui-btn-fluid" lay-filter="reg" type="button" lay-submit>注册</button>
        </div>
    </form>
</div>

<script type="text/javascript" src="<?=TEMPLATE;?>/assets/libs/layui/layui.js"></script>
<script type="text/javascript" src="<?=TEMPLATE;?>/assets/js/common.js?v=318"></script>
<script>
    layui.use(['jquery', 'layer', 'form', 'admin',  'element',  'notice'], function () {
        var $ = layui.jquery;
        var layer = layui.layer;
        var form = layui.form;
        var admin = layui.admin;
        var notice = layui.notice;
        var element = layui.element;
        $('.login-wrapper').removeClass('layui-hide');
        
        /* 图形验证码 */
        var captchaUrl = '../includes/lib/ValidateCode.php';
        $('img.login-captcha').click(function () {
            this.src = captchaUrl + '?r=' + (new Date).getTime();
        }).trigger('click');

        form.on('submit(reg)', function (data) {
        	var apikey = getApiKeyFromUrl(); // 从链接中获取apikey参数
        	var user = $("input[name='user']").val();
        	var pwd = $("input[name='pwd']").val();
        	var email = $("input[name='email']").val();
        	var qq = $("input[name='qq']").val();
        	var code = $("input[name='code']").val();
        	
        	notice.msg('正在注册中..', {icon: 4, close: true});
        	$.ajax({
        		type: "POST",
        		url: "ajax.php?act=reg",
        		data: {
        			"apikey": apikey,
        			"user": user,
        			"pwd": pwd,
        			"email": email,
        			"qq": qq,
        			"code": code
        		},
        		dataType: 'json',
        		success: function(data) {
        			notice.destroy();
        			if (data.code == 0) {
            			    notice.success({
            			    title: '消息通知',
                            message: data.msg,
                    		position: 'topCenter',
                    		audio: ''
                		});
        			    setTimeout(function() {
                		    window.location.href = "./login.php";
            		    }, 1500); // 1.5秒后跳转
        			} else {
        				notice.error({
                            title: '消息通知',
                            message: data.msg,
                            position:'topCenter',
                            audio:''
                        });
        			}
        		}
        	});
        });
        
        function getApiKeyFromUrl() {
            var urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('apikey');
        }
        
    });
</script>
</body>
</html>