function showNotification(msg, type) {
    layui.use(['form', 'notice'], function () {
        var $ = layui.jquery;
        var form = layui.form;
        var notice = layui.notice;
        if (type == 'success') {
            notice.success({
                title: msg,
                message: '您有一条新的消息注意查收！',
                position: 'topCenter',
                animateInside: true,
                balloon: true,
                audio: '2'
            });
        } else if (type == 'error') {
            notice.error({
                title: msg,
                message: '您有一条新的消息注意查收！',
                position: 'topCenter',
                animateInside: true,
                balloon: true,
                audio: '2'
            });
        } else if (type == 'info') {
            notice.info({
                title: msg,
                message: '您有一条新的消息注意查收！',
                position: 'topCenter',
                animateInside: true,
                balloon: true,
                audio: '2'
            });
        } else if (type == 'loading') {
            notice.msg(msg, {icon: 4, close: true});
        } else if (type == 'close') {
            notice.destroy();
        } else if (type == '') {
            notice.show({
                title: msg,
                message: '您有一条新的消息注意查收！',
                position: 'topCenter',
                animateInside: true,
                balloon: true,
                audio: '2'
            });
        }
    });
}