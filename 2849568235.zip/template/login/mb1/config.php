<?php
return [
    'version' => '1.0',
    'zuozhe' => 'HuanYing',
    'jieshao' => 'easyadmin模板',
];
?>