<?php
return [
    'version' => '1.0',
    'zuozhe' => 'HuanYing',
    'jieshao' => 'prea admin官方模板',
];
?>