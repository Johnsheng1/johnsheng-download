<?php
include_once './includes/common.php';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$conf['title']?> - 二级域名分发服务平台</title>
    <meta name="keywords" content="<?=$conf['keywords']?>"/>
    <meta name="description" content="<?php echo htmlspecialchars($conf['description']); ?>"/>
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
    <meta name="author" content="HuanYing">
    <meta name="founder" content="幻影网络科技">
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
 :root {
    --primary-color: #2563eb;
    --primary-light: #3b82f6;
    --primary-dark: #1d4ed8;
    --secondary-color: #f9fafb;
    --text-color: #1f2937;
    --text-light: #6b7280;
    --border-color: #e5e7eb;
    --shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    --transition: all 0.3s ease;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: var(--text-color);
    background-color: var(--secondary-color);
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

header {
    background-color: white;
    box-shadow: var(--shadow);
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1000;
}

nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 0;
}

.logo {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--primary-color);
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
}

.logo i {
    font-size: 2rem;
}

.pro-badge {
    margin-left: 4px;
    background-color: #ff4757;
    color: white;
    font-size: 10px;
    font-weight: bold;
    padding: 2px 6px;
    border-radius: 4px;
    position: relative;
    top: -3px;
}

.nav-links {
    display: flex;
    gap: 30px;
}

.nav-links a {
    text-decoration: none;
    color: var(--text-color);
    font-weight: 500;
    transition: var(--transition);
}

.nav-links a:hover {
    color: var(--primary-color);
}

.cta-button {
    background-color: var(--primary-color);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
}

.cta-button:hover {
    background-color: var(--primary-dark);
}

.outline-button {
    background: none;
    border: 1px solid var(--primary-color);
    color: var(--primary-color);
    padding: 10px 20px;
    border-radius: 5px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
}

.outline-button:hover {
    background-color: var(--primary-color);
    color: white;
}

.hero {
    padding: 180px 0 100px;
    min-height: 80vh;
    display: flex;
    align-items: center;
}

.hero-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 50px;
}

.hero-text {
    flex: 1;
    max-width: 500px;
}

.hero-text h1 {
    font-size: 3.5rem;
    margin-bottom: 20px;
    color: var(--text-color);
    line-height: 1.2;
}

.hero-text p {
    font-size: 1.2rem;
    color: var(--text-light);
    margin-bottom: 30px;
    line-height: 1.6;
}

.hero-buttons {
    display: flex;
    gap: 15px;
}

.hero-image {
    flex: 1;
    max-width: 500px;
    height: 400px;
}

.hero-image svg {
    width: 100%;
    height: 100%;
}

.features {
    padding: 100px 0;
    background-color: white;
}

.section-title {
    text-align: center;
    margin-bottom: 60px;
}

.section-title h2 {
    font-size: 2.5rem;
    margin-bottom: 15px;
}

.section-title p {
    color: var(--text-light);
    max-width: 600px;
    margin: 0 auto;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.feature-card {
    background-color: var(--secondary-color);
    border-radius: 10px;
    padding: 30px;
    box-shadow: var(--shadow);
    transition: var(--transition);
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
}

.feature-icon {
    font-size: 2.5rem;
    color: var(--primary-color);
    margin-bottom: 20px;
}

.feature-card h3 {
    font-size: 1.5rem;
    margin-bottom: 15px;
}

.feature-card p {
    color: var(--text-light);
}

.pricing {
    padding: 100px 0;
    background-color: var(--secondary-color);
}

.pricing-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.pricing-card {
    background-color: var(--secondary-color);
    border-radius: 10px;
    padding: 40px 30px;
    box-shadow: var(--shadow);
    text-align: center;
    transition: var(--transition);
}

.pricing-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
}

.pricing-card.popular {
    border: 2px solid var(--primary-color);
    position: relative;
}

.popular-tag {
    position: absolute;
    top: -15px;
    right: 20px;
    background-color: var(--primary-color);
    color: white;
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.pricing-card h3 {
    font-size: 1.5rem;
    margin-bottom: 20px;
}

.price {
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 20px;
    color: var(--primary-color);
}

.price span {
    font-size: 1rem;
    color: var(--text-light);
}

.features-list {
    list-style: none;
    margin-bottom: 30px;
}

.features-list li {
    margin-bottom: 10px;
    color: var(--text-light);
}

.features-list li i {
    color: var(--primary-color);
    margin-right: 10px;
}

.testimonials {
    padding: 100px 0;
    background-color: white;
}

.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.testimonial-card {
    background-color: white;
    border-radius: 10px;
    padding: 30px;
    box-shadow: var(--shadow);
}

.testimonial-content {
    margin-bottom: 20px;
    font-style: italic;
    color: var(--text-light);
}

.testimonial-author {
    display: flex;
    align-items: center;
    gap: 15px;
}

.author-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background-color: var(--primary-light);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
}

.author-info h4 {
    margin-bottom: 5px;
}

.author-info p {
    color: var(--text-light);
    font-size: 0.9rem;
}

.team-promise {
    padding: 100px 0;
    background-color: white;
}

.promise-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
}

.promise-card {
    text-align: center;
    padding: 30px;
}

.promise-icon {
    font-size: 3rem;
    color: var(--primary-color);
    margin-bottom: 20px;
}

.promise-card h3 {
    font-size: 1.5rem;
    margin-bottom: 15px;
}

.promise-card p {
    color: var(--text-light);
}

.domain-showcase {
    padding: 100px 0;
    background-color: var(--secondary-color);
}

.domain-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.domain-card {
    background-color: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: var(--shadow);
    text-align: center;
    transition: var(--transition);
}

.domain-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
}

.domain-card h3 {
    font-size: 1.2rem;
    margin-bottom: 10px;
}

.domain-card p {
    color: var(--text-light);
    font-size: 0.9rem;
}

.faq {
    padding: 100px 0;
    background-color: var(--secondary-color)
}

.faq-container {
    max-width: 800px;
    margin: 0 auto;
}

.faq-item {
    background-color: var(--secondary-color);
    border-radius: 10px;
    margin-bottom: 15px;
    box-shadow: var(--shadow);
    overflow: hidden;
}

.faq-question {
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    font-weight: 600;
}

.faq-question i {
    transition: var(--transition);
}

.faq-answer {
    padding: 0 20px;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
}

.faq-item.active .faq-question i {
    transform: rotate(180deg);
}

.faq-item.active .faq-answer {
    padding: 0 20px 20px;
    max-height: 200px;
}

footer {
    background-color: var(--text-color);
    color: white;
    padding: 60px 0 20px;
}

.footer-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
    margin-bottom: 40px;
}

.footer-column h3 {
    font-size: 1.2rem;
    margin-bottom: 20px;
}

.footer-links {
    list-style: none;
}

.footer-links li {
    margin-bottom: 10px;
}

.footer-links a {
    color: #9ca3af;
    text-decoration: none;
    transition: var(--transition);
}

.footer-links a:hover {
    color: white;
}

.social-links {
    display: flex;
    gap: 15px;
}

.social-links a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background-color: #374151;
    border-radius: 50%;
    color: white;
    transition: var(--transition);
}

.social-links a:hover {
    background-color: var(--primary-color);
    transform: translateY(-3px);
}

.footer-bottom {
    text-align: center;
    padding-top: 20px;
    border-top: 1px solid #374151;
    color: #9ca3af;
    font-size: 0.9rem;
}

@media (max-width: 992px) {
    .hero-content {
        flex-direction: column;
    }
    
    .hero-text, .hero-image {
        max-width: 100%;
        text-align: center;
    }
    
    .hero-buttons {
        justify-content: center;
    }
}

@media (max-width: 768px) {
    .logo {
        font-size: 1.2rem;
    }
    .hero-text h1 {
        font-size: 2.5rem;
    }
    
    .nav-links {
        display: none;
    }
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.fade-in {
    animation: fadeIn 0.8s forwards;
}

/* 浮动按钮容器 */
.float-buttons {
    position: fixed;
    right: 20px;
    bottom: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    z-index: 999;
}

/* 浮动按钮基础样式 */
.float-button {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background-color: var(--primary-color);
    color: white;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease;
    opacity: 0;
    transform: translateY(20px);
    visibility: hidden;
}

/* 显示按钮时的样式 */
.float-button.show {
    opacity: 1;
    transform: translateY(0);
    visibility: visible;
}

/* 按钮悬停效果 */
.float-button:hover {
    background-color: var(--primary-dark);
    transform: translateY(-3px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

/* 联系客服按钮特殊样式 */
#contactBtn {
    background-color: #28a745;
}

#contactBtn:hover {
    background-color: #218838;
}

/* 移动端适配 */
@media (max-width: 768px) {
    .float-buttons {
        right: 10px;
        bottom: 10px;
        gap: 8px;
    }

    .float-button {
        width: 40px;
        height: 40px;
        font-size: 16px;
    }

    /* 在小屏幕上调整按钮间距 */
    .float-button + .float-button {
        margin-top: 5px;
    }

    /* 确保在移动端也能显示图标 */
    .float-button i {
        font-size: 16px;
    }

    /* 优化移动端触摸区域 */
    .float-button {
        touch-action: manipulation;
    }

    /* 添加安全区域边距（适配全面屏手机） */
    @supports (padding: max(0px)) {
        .float-buttons {
            padding-bottom: max(10px, env(safe-area-inset-bottom));
            padding-right: max(10px, env(safe-area-inset-right));
        }
    }
}

/* 暗色模式支持 */
@media (prefers-color-scheme: dark) {
    .float-button {
        background-color: var(--primary-dark);
    }

    #contactBtn {
        background-color: #1e7e34;
    }

    .float-button:hover {
        background-color: var(--primary-light);
    }
}

/* 添加过渡动画 */
.float-button {
    animation: float-in 0.3s ease forwards;
}

@keyframes float-in {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* 适配不同设备的悬停效果 */
@media (hover: hover) {
    .float-button:hover {
        transform: translateY(-3px);
    }
}

/* 点击效果 */
.float-button:active {
    transform: translateY(1px);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

    </style>
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <a href="#" class="logo">
                <?=$conf['title']?><span class="pro-badge">V<?php echo $auth['app_version'] ?? '1.0'; ?></span>
                </a>
                <div class="nav-links">
                    <a href="#features">功能</a>
                    <a href="#testimonials">客户案例</a>
                    <a href="#faq">常见问题</a>
                </div>
                                    <button class="outline-button" onclick="window.location.href='/user'">登录</button>
                            </nav>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text fade-in">
                    <h1><?=$conf['title']?></h1>
                    <p><?php echo htmlspecialchars($conf['description']); ?></p>
                    <div class="hero-buttons">
                                                    <button class="cta-button" onclick="window.location.href='/user'">立即注册</button>
                            <button class="outline-button" onclick="window.location.href='/user'">登录</button>
                                            </div>
                </div>
                <img src="./template/mb11/designer.svg" alt="<?=$conf['title']?>" class="fade-in" width="300px">
            </div>
        </div>
    </section>

    <section class="features" id="features">
        <div class="container">
            <div class="section-title">
                <h2>强大功能，满足您的需求</h2>
                <p>为您提供全面的二级域名管理解决方案，帮助您简化流程，提升效率</p>
            </div>
            <div class="features-grid">
                <div class="feature-card scroll-animation">
                    <div class="feature-icon">
                        <i class="fas fa-ban"></i>
                    </div>
                    <h3>违规检测</h3>
                    <p>实时监控域名内容，自动屏蔽违规信息，确保域名解析合法合规。</p>
                </div>
                <div class="feature-card scroll-animation">
                    <div class="feature-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3>毫秒级解析</h3>
                    <p>与顶级DNS服务商合作，提供毫秒级解析速度，确保用户访问流畅无延迟。</p>
                </div>
                <div class="feature-card scroll-animation">
                    <div class="feature-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <h3>便捷管理</h3>
                    <p>直观的用户界面和强大的管理功能，支持批量操作和实时监控，优化资源配置。</p>
                </div>
            </div>
        </div>
    </section>

    
    <section class="team-promise">
        <div class="container">
            <div class="section-title">
                <h2>我们的承诺</h2>
                <p>我们致力于为客户提供最优质的服务和解决方案</p>
            </div>
            <div class="promise-container">
                <div class="promise-card">
                    <div class="promise-icon">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    <h3>稳定可靠</h3>
                    <p>99.9%的高可用性，确保服务稳定运行，保障您的业务不间断。</p>
                </div>
                <div class="promise-card">
                    <div class="promise-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>售后无忧</h3>
                    <p>7×24小时全天候支持，快速响应并解决您的每一个问题。</p>
                </div>
                <div class="promise-card">
                    <div class="promise-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3>极速解析</h3>
                    <p>毫秒级DNS解析速度，稳定解析，确保用户访问流畅无延迟。</p>
                </div>
                <div class="promise-card">
                    <div class="promise-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <h3>便捷管理</h3>
                    <p>直观的用户界面，支持批量操作、一键配置，轻松管理所有域名解析。</p>
                </div>
            </div>
        </div>
    </section>

   

    <section class="testimonials" id="testimonials">
        <div class="container">
            <div class="section-title">
                <h2>客户成功案例</h2>
                <p>看看我们的客户如何通过<?=$conf['title']?>提升业务表现</p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card scroll-animation">
                    <div class="testimonial-content">
                        "<?=$conf['title']?>提供的多种域名选择帮助我们满足了不同用户的需求，提升了品牌形象，客户转化率提高了35%。"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">JD</div>
                        <div class="author-info">
                            <h4>John Davis</h4>
                            <p>市场总监, BrandHub</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card scroll-animation">
                    <div class="testimonial-content">
                        "毫秒级解析速度显著提升了我们的用户体验，全球用户访问延迟问题得到了有效解决，客户满意度提高了40%。"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">SL</div>
                        <div class="author-info">
                            <h4>Sarah Lee</h4>
                            <p>产品总监, GlobalTech</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card scroll-animation">
                    <div class="testimonial-content">
                        "用户中心的便捷管理功能让我们的团队能够高效处理复杂的域名解析需求，管理效率提升了50%，团队可以专注于核心业务。"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">RM</div>
                        <div class="author-info">
                            <h4>Robert Martinez</h4>
                            <p>IT运营经理, EfficientSolutions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="faq" id="faq">
        <div class="container">
            <div class="section-title">
                <h2>常见问题</h2>
                <p>找到您需要的答案</p>
            </div>
            <div class="faq-container">
                <div class="faq-item scroll-animation">
                    <div class="faq-question">
                        <span><?=$conf['title']?>支持哪些类型的二级域名？</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p><?=$conf['title']?>支持所有标准的二级域名类型，包括但不限于.com、.net、.org、.cn等。我们还支持自定义域名和多级子域名。</p>
                    </div>
                </div>
                <div class="faq-item scroll-animation">
                    <div class="faq-question">
                        <span>新人如何使用<?=$conf['title']?>？</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>使用过程非常简单。您只需要在我们的平台上创建新的域名记录，然后更新DNS设置即可。我们的支持团队会全程指导您完成迁移。</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-container">
                <div class="footer-column">
                    <h3><?=$conf['title']?></h3>
                    <p><?php echo htmlspecialchars($conf['description']); ?></p>
                </div>
                <div class="footer-column">
                    <h3>联系我们</h3>
                    <ul class="footer-links">
                        <li><i class="fab fa-qq"></i> <a href="https://wpa.qq.com/msgrd?v=3&uin=<?=$conf['qq']?>&site=qq&menu=yes&jumpflag=1" target="_blank">QQ: <?=$conf['qq']?></a></li>
                                                <li><i class="fas fa-envelope"></i> <a href="mailto:<?=$conf['qq']?>@qq.com">邮箱: <?=$conf['qq']?>@qq.com</a></li>
                    </ul>
                </div>
                
            </div>
            <div class="footer-bottom">
                <p>Copyright © 2025 <?=$conf['title']?>. All rights reserved.</p>
                <p><a href="https://beian.miit.gov.cn/" target="_blank"><?=$conf['icp']?></a></p>
            </div>
        </div>
    </footer>
    <div class="float-buttons">
        <button class="float-button" id="contactBtn" title="联系客服">
            <i class="fas fa-headset"></i>
        </button>
        <button class="float-button" id="backToTopBtn" title="返回顶部">
            <i class="fas fa-arrow-up"></i>
        </button>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const scrollAnimations = document.querySelectorAll('.scroll-animation');
            
            function checkScroll() {
                scrollAnimations.forEach(animation => {
                    const animationPosition = animation.getBoundingClientRect().top;
                    const screenPosition = window.innerHeight / 1.2;
                    
                    if (animationPosition < screenPosition) {
                        animation.classList.add('visible');
                    }
                });
            }
            
            window.addEventListener('scroll', checkScroll);
            checkScroll();
            
            const faqItems = document.querySelectorAll('.faq-item');
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question');
                
                question.addEventListener('click', () => {
                    const isActive = item.classList.contains('active');
                    
                    faqItems.forEach(faq => {
                        faq.classList.remove('active');
                    });
                    
                    if (!isActive) {
                        item.classList.add('active');
                    }
                });
            });
            
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    if (targetId === '#') return;
                    
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 80,
                            behavior: 'smooth'
                        });
                    }
                });
            });

            const backToTopBtn = document.getElementById('backToTopBtn');
            const contactBtn = document.getElementById('contactBtn');

            // 返回顶部按钮显示/隐藏逻辑
            window.addEventListener('scroll', () => {
                if (window.scrollY > 300) {
                    backToTopBtn.classList.add('show');
                } else {
                    backToTopBtn.classList.remove('show');
                }
            });

            // 返回顶部点击事件
            backToTopBtn.addEventListener('click', () => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

            // 联系客服按钮始终显示
            contactBtn.classList.add('show');

            // 联系客服点击事件
            contactBtn.addEventListener('click', () => {
                window.open('https://wpa.qq.com/msgrd?v=3&uin=<?php  echo $data['data']['ySiteInfo']['webmasterQq']  ?>&site=qq&menu=yes&jumpflag=1', '_blank');
            });
        });
    </script>
</body>
</html>